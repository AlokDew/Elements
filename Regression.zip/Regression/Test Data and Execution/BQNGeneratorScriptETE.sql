Use EAM
--******************************************************
--		ICEP
--******************************************************
--'7B77C00AZ20,7B77C00AZ21'
Exec BEQResponse_Generator '9A77C00AA01',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190101;
MedPartBEntStartDate=20190101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'						
	
--Remove 88,89,91,92 Blank	Position 717
--------------------------------------	
					
Exec BEQResponse_Generator '9A77C00AA02',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200401;
MedPartBEntStartDate=20200401;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

--Remove 88,89,91,92 Blank	Position 717
--------------------------------------				
--'7B77C00AZ23'					
Exec BEQResponse_Generator '9A77C00AA03',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					
					
--Remove 88,89,91,92 Blank	Position 717
--------------------------------------
--'7B77C00AZ24'
exec BEQResponse_Generator '9A77C00AA04',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'				
					
--Remove 88,89,91,92 Blank Position 717
					
--******************************************************
--		IEP
--******************************************************
--'7B77C00AZ25,7B77C00AZ26'
Exec BEQResponse_Generator '9A77C00AA05,9A77C00AA06',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
PartDEligibilityStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'
					
--Remove 88,89,91,92 Blank Position 717
---------------------------------------
--'7B77C00AZ51'
Exec BEQResponse_Generator '9A77C00AA07',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'		

--No further update required 	
-----------------------------------------
--'7B77C00AZ53'
Exec BEQResponse_Generator '9A77C00AA08',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
PartDEligibilityStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

--Remove 88,89,91,92 Blank	 Position 717	
					
--******************************************************
--		IEP2
--******************************************************
--'7B77C00AZ57,7B77C00AZ58'					
Exec BEQResponse_Generator '9A77C00AA09,9A77C00AA10',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
PartDEligibilityStartDate=20190101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

--No further update required 
--------------------------------------------------					
--'7B77C00AZ63,7B77C00AZ64'	
Exec BEQResponse_Generator '9A77C00AA11,9A77C00AA12',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
PartDEligibilityStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'				
					
--No further update required 	
			
--******************************************************
--		MAOEP
--******************************************************
--7B77C00AZ65	
Exec BEQResponse_Generator '9A77C00AA13',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20200101;
PartCDPlanType=01;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					

--No further update required 
----------------------------------------

--7C77C02MO56
Exec BEQResponse_Generator '9A77C00AA14',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20200101;
PartCDPlanType=31;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;' 

--No Further update required					
----------------------------------------

--7C77C02MO57
Exec BEQResponse_Generator '9A77C00AA15',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20200101;
PartCDPlanType=09;
PartCEnrollStartDate=20190701;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

--No Further update required				
----------------------------------------
	
--7B77C01AZ73
Exec BEQResponse_Generator '9A77C00AA16',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200401;
MedPartBEntStartDate=20200301;
PartCDEnrollStartDate=20200801;
PartCDPlanType=40;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					

--No Further update required				
----------------------------------------

--7B77C01AZ68
Exec BEQResponse_Generator '9A77C00AA17',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200401;
MedPartBEntStartDate=20200301;
PartCDEnrollStartDate=20200501;
PartCDPlanType=40;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

--No Further update required				
----------------------------------------
--7C77C03MO56

Exec BEQResponse_Generator '9A77C00AA18',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20200101;
PartCDPlanType=46;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'			

--No Further update required				
----------------------------------------
--7C77C01MO56

Exec BEQResponse_Generator '9A77C00AA19',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190201;
MedPartBEntStartDate=20190201;
PartCPlanType=50;
PartCEnrollStartDate=20200401;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					

--No Further update required				
----------------------------------------				
					
--******************************************************
--		AEP and OEPI
--******************************************************				
--'7B77C01AZ93,7B77C01AZ94,7B77C01AZ95'					
Exec BEQResponse_Generator '9A77C00AA20,9A77C00AA21,9A77C00AA22',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200101;
PartDEligibilityStartDate=20200101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

--No Further update required				
----------------------------------------				
					
					
					
					
					
					
					
					

					
					
					
					
					
					
					
					
					
					
					
					
				
					
					
					
					
					
					
					
					
				
					
				
					
					
					
					
					
					
			
					
					
					
					
					
					
					
				
					
					
					
				
					
					
					
					
					
					
					

					
					
					
					

					
					
					
					
					
					

					
					
					
					
					
					
					
					
				
					
					
					
					
					
					
					
					
					
					
