Select * from tbtransactions where HIC like '2A77AA0TR%'

Select multiple from tbplan_pbp


Select TransStatus, Count(1) as 'Total Records' from tbtransactions
where PlanID ='H1004' And HIC like '2A77AA0TR%'
Group By TransStatus

Select Count(*) as 'Total LIS Span Via LISHIST'
From tbLISHist
where  HIC like '2A77AA0TR%'

Select Count(*) as 'Member Total LIS'
From tbMemberInfoLISLog M Join tbtransactions T
On M.Memcodnum = T.MemCodNum Where T.HIC like '2A77AA0TR%'

Select TransStatus, Count(1) as 'Total Records' from tbtransactions
where PlanID ='H1005' And HIC like '2A77AA0TR%'
Group By TransStatus

Select distinct Count(*) as 'Member Total LIS'
From tbMemberInfoLISLog M Join tbtransactions T
On M.Memcodnum = T.MemCodNum 
Where T.PlanID = 'H1005' And T.HIC like '2A77AA0TR%'

Select Distinct Left(HIC,9) as 'MBI',PlanID,SpanTYpe,StartDate, EndDate 
From tbENRLSpans Where PlanId In('H1004','H1005') and SpanType = 'EFFD' and HIC like '2A77AA0TR%'

Select Count(*) as 'Total LIS Span Via LISHIST'
From tbLISHist
where  HIC like '2A77AA0TR%'

Select distinct Count(*) as 'Member Total LIS'
From tbMemberInfoLISLog M Join tbtransactions T
On M.Memcodnum = T.MemCodNum 
Where T.PlanID = 'H1005' ANd T.HIC like '2A77AA0TR%'


Select Distinct T.HIC,PartDSubsLevel,LowIncCoPayCat,LowIncomeCoPayEffectiveDate,LowIncomeCoPayEndDate,LISType,ChangeSource
From tbMemberInfoLISLog M Join tbtransactions T
On M.Memcodnum = T.MemCodNum Where T.HIC like '2A77AA0TR%'
Order by HIC



exec BEQResponse_Generator '7C77C01AD02',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20110201;
MedPartBEntStartDate=20110201;
PartDEnrEffDateEmpSubsStartDate1=20110201;
PartDEligibilityStartDate=20110201;
DeemedLISEffDate1=20190101;
DeemedLISEndDate1=20190630;
PartDPremiumSubsidyPercent1=050;
CopayLelelId1=4'



Declare @MBI varchar(100) = '7C77C01AD02'

Select HIC,PlanID,SpanTYpe,StartDate, EndDate from tbENRLSpans Where SpanType = 'EFFD' and hic like @MBI

Select Distinct T.HIC,PartDSubsLevel,LowIncCoPayCat,LowIncomeCoPayEffectiveDate,LowIncomeCoPayEndDate,LISType,ChangeSource,Valid,DateEntered
From tbMemberInfoLISLog M Join tbtransactions T
On M.Memcodnum = T.MemCodNum Where T.HIC like @MBI
Order by DateEntered 

Select HIC,PlanID,ContractYear,LISLevel,LISCoPayLevelCat,LISStartDate,LISEndDate,SubsidyCode,'LISHIST'
From tbLISHist
where  hic like  @MBI





