
Select * from tbPlanPBPSegPremSpans Where PlanID In ('H1001','H0001') And EffectiveDate like '%2020%'

Select * from Member_Premium_Part_C Where PlanID In ('H1001','H0001') And EFF_DATE like '%2021%'

Select multiple from tbplan_pbp

Update tbplan_pbp  Set   multiple = 0

Delete from [EAM].[dbo].[tbMMPMemberLoad]
where (((planid = 'H1001' and PBPid = '001') or (planid = 'H0001' and PBPid in ('001', '002'))) and EffectiveDate >='2020-01-01')

Select * from [tbEAM_OSBConfig] 
Delete from [dbo].[tbEAM_OSBConfig] Where PlanID not in ('H1001','H0001') 

Delete from [dbo].[tbEGWPPlanPbpAssociation] 


--Turn OFF MemberDupeCheck

--Restart Services

Delete from [tbMMPMemberLoad]

SELECT @@VERSION AS 'SQL Server PDW Version'; 

Select count(1) from tbtransactions where hic like '2C77C40%'
Select count(1) from tbtransactions where hic like '3C77C40%'
Select count(1) from tbtransactions where hic like '4C77C40%'
Select count(1) from tbtransactions where hic like '5C77C40%'
Select count(1) from tbtransactions where hic like '6C77C40%'
Select count(1) from tbtransactions where hic like '7C77C40%'
Select count(1) from tbtransactions where hic like '8C77C40%'
Select count(1) from tbtransactions where hic like '9C77C40%'


-------------------------------------------------------------------------------------------------------------
--1. TRR1(2C,5C,8C) -> PWO(S,R,R)
--2. EAF1(2C,3C,4C,7C) - > PWO (D,,,,,)S
--3. TRR2(2c,3c,4c,7c) - > PWO (D,,,,,)S
--4. EAF2(2c, 3c,4c,5c,6c,7c,8c) - > (D,,,,,,D)
--5. TRR3(2c, 3c,4c,5c,6c,7c,8c) - > (D,,,,,,D)
-------------------------------------------------------------------------------------------------------------

-- [Step 1] Run query and confirm all 2712 records are loaded and present with TransStatus �5�

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2019_TRR_File1.txt'

select TransStatus, count(1) as TotalRecords  from EAM..tbTransactions t Inner join
EAMWarehouse..[HistoryInputManagerTrrData] W
on W.claimnumber=t.hic Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
where t.effectivedate='2019-01-01 00:00:00'
And
R.requestURI= @FileName
group by transstatus


------------------------------------------------------------
--[ Step 2]

-- Run query and confirm all records 
--OSB = Null, RX = Null, 
--MBI starting with 2 - PWO = 4, 
--MBI starting with 5 and 8 - PWO = 3 

/*
(No column name)	planid	pbp	memberstatus	rxid	rxgroupid	rxbin	rxpcn	osbflag	pwoption
2C	H0001	002	2	NULL	NULL	NULL	NULL	NULL	4
5C	H0001	002	2	NULL	NULL	NULL	NULL	NULL	3
8C	H0001	002	2	NULL	NULL	NULL	NULL	NULL	3
*/

-- Run below query and Validate Expected Result as in Step 1

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2019_TRR_File1.txt'

Select distinct Left(HIC,2),planid, pbp, memberstatus, Left(rxid,4) as rxid, rxgroupid, rxbin, rxpcn, osbflag, pwoption
from tbeenrlmembers e inner join tbmemberinfo m
on e.memcodnum=m.memcodnum where e.memcodnum in (
select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on w.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2019-01-01 00:00:00')
---PWO 4 - S; 3- R


--Just check for H0001 and 002 plan 

select PlanId,PBP,HIC as MBI,PartCPremium, CurrentEffDate,  * from tbmemberinfo inner join tbeenrlmembers
on tbmemberinfo.memcodnum = tbeenrlmembers.memcodnum
where tbeenrlmembers.HIC LIKE '2C%'  OR HIC LIKE '5C%' 
Order by tbeenrlmembers.HIC Asc

select BASIC_PREMIUM,EFF_DATE, EXP_DATE,* FROM Member_Premium_Part_C where (planid = 'H0001' and PBP = '002')  and EFF_DATE >= '2020-01-01 00:00:00.000'

--Select * from [dbo].[tbPremiumWitholdOptions]


---------------------------------------------------------------------
--4C  TC 61 Plan H1001/001 OSB Medical 01012020 -> 4C TC 78 Plan H1001/001 OSB Dental 01012025
--5C  TC 61 Plan H0001/002 OSB None 01012020   -> 5C TC 78 Plan H0001/002 OSB Medical 01012025
--6C  TC 61 Plan H1001/001 OSB Medical 01012020 -> 6C TC 78 Plan H1001/001 OSB None Medical 01012025

--OSB  Configuration
--	1. H1001/001 Medical - 2020
--	2. H0001/002 Medical  - 2025
--	3. H0001/001 Dental  -  2025

-- [Step 3] Load EAF file1 and once complete Confirm data from EAF as per expectations (4520 records should be present)

--***********************CHECK MENBER DUPE CHECK BEFORE LOAD, MULTIPLE ON. OSB CONFIG ******************* 

select  transstatus, t.planid, t.pbpid, t.effectivedate, t.transcode, t.rxgroup, t.rxbin, t.rxpcn, t.osbflag, t.prempart from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename= 'EAF_01File001_20200301.txt' 
and t.effectivedate='2020-01-01 00:00:00'


---Added by me
select  distinct Left(t.hic,2),transstatus,t.planid, t.pbpid, t.effectivedate, t.transcode, t.rxgroup, t.rxbin, t.rxpcn, t.osbflag, t.prempart from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename= 'EAF_01File001_20200301.txt' 
and t.effectivedate='2020-01-01 00:00:00'

/*
(No column name)	transstatus	planid	pbpid	effectivedate	transcode	rxgroup	rxbin	rxpcn	osbflag	prempart
2C	0	H1001	001	2020-01-01 00:00:00	61	123	456	789	1	1
3C	0	H1001	001	2020-01-01 00:00:00	61	123	456	789	1	1
4C	0	H1001	001	2020-01-01 00:00:00	61	123	456	789	1	1
6C	0	H1001	001	2020-01-01 00:00:00	61	123	456	789	1	1
7C	0	H1001	001	2020-01-01 00:00:00	61	123	456	789	1	1
*/

--Select error,ApplicantHIcn,* from elecappfile where filename = 'EAF_File1_20200301.txt' and isprocessed = 0 

---------------------------------------------------------------------

-- [Step 4]Update data imported from EAF to sent to CMS

update tbtransactions
set transstatus=4
from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename= 'EAF_01File001_20200301.txt'
and t.effectivedate='2020-01-01 00:00:00'

---------------------------------------------------------------------------------------
-- [Step 5] use this query to update the transid with plantracking id in the TRR File 2

select distinct t.transid, hic
from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename= 'EAF_01File001_20200301.txt' 
and t.effectivedate='2020-01-01 00:00:00'
order by hic

-------------------------------------------------------------------------------
-- [Step 6] Load TRR File 2 

-- Confirm all transactions are Accepted by CMS

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File2.txt'
select TransStatus, count(1) as TotalRecords from EAM..tbTransactions t Inner join
EAMWarehouse..[HistoryInputManagerTrrData] W
on W.claimnumber=t.hic Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
where t.effectivedate='2020-01-01 00:00:00'
And
R.requestURI = @FileName
group by transstatus


--Added by ME - Check Trans Stauts is 5
select  distinct Left(t.hic,2),transstatus,t.planid, t.pbpid, t.effectivedate, t.transcode, t.rxgroup, t.rxbin, t.rxpcn, t.osbflag, t.prempart from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename= 'EAF_01File001_20200301.txt'
and t.effectivedate='2020-01-01 00:00:00'
and t.TransStatus = 4

/*
7C - Rx Change TC 72
8C - PWO - TC 75
4C, 5C,6C, -  OSB  - TC 78 */


----------------------------------------------------------------------

---[Step 7] Run below query and Validate expected result Mentioned in Step2

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File2.txt'
Select  distinct LEFT(HIC,2) as 'HIC',planid, pbp, memberstatus, LEFT(rxid,4) as 'rxid', rxgroupid, rxbin, rxpcn, osbflag, pwoption
--Select  HIC as 'HIC',planid, pbp, memberstatus, LEFT(rxid,4) as 'rxid', rxgroupid, rxbin, rxpcn, osbflag, pwoption
from tbeenrlmembers e inner join tbmemberinfo m
on e.memcodnum=m.memcodnum where e.memcodnum in (
select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on w.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2020-01-01 00:00:00')
order by hic 

/*
HIC	planid	pbp	memberstatus	rxid	rxgroupid	rxbin	rxpcn	osbflag	pwoption
2C	H1001	001		2			ANUR		123		456		789		1			1
2C	H1001	001		2			MORE		123		456		789		1			1
3C	H1001	001		2			MOR1		123		456		789		1			1
3C	H1001	001		2			MOR9		123		456		789		1			1
4C	H1001	001		2			ANUR		123		456		789		1			1
4C	H1001	001		2			MORE		123		456		789		1			1
6C	H1001	001		2			ANUR		123		456		789		1			1
6C	H1001	001		2			MORE		123		456		789		1			1
7C	H1001	001		2			ANUR		123		456		789		1			1
7C	H1001	001		2			MORE		123		456		789		1			1
*/


select HIC as MBI,PartCPremium,* from tbmemberinfo inner join tbeenrlmembers
on tbmemberinfo.memcodnum = tbeenrlmembers.memcodnum
where tbeenrlmembers.HIC LIKE '2C%'  OR HIC LIKE '3C%'  OR HIC LIKE '4C%'  OR HIC LIKE '6C%' 
Order by tbeenrlmembers.HIC Asc

select BASIC_PREMIUM,EFF_DATE, EXP_DATE,* FROM Member_Premium_Part_C where (planid = 'H1001' and PBP='001')  and EFF_DATE >= '2020-01-01 00:00:00.000'

select OSBPremium,* from [dbo].[tbEAM_OSBConfig] where planid = 'H1001' and PBPID = '001'

select OSBID,hic as MBI,* from [dbo].[tbEAM_OSBMemberInfo] inner join tbeenrlmembers
on tbEAM_OSBMemberInfo.memcodnum = tbeenrlmembers.memcodnum
where tbeenrlmembers.memcodnum in (select memcodnum from tbeenrlmembers where HIC LIKE '2C%' OR HIC LIKE '3C%'  OR HIC LIKE '4C%' OR HIC LIKE '6C%' )
order by MBI  


------------------------------------------------------------------------------------------------------
/*WORK AROUND
Select * from tbeenrlmembers
Select rxid,rxgroup,rxbin,rxpcn,premPart,* from tbtransactions where hic = '3C77C40GT39'
Select rxid,rxgroupid,rxbin,rxpcn,PWOption,* from tbmemberinfo where memCodNum = '70989'

Select rxid,rxgroup,rxbin,rxpcn,premPart,* from tbtransactions where hic = '3C77C40GT67'
Select rxid,rxgroupid,rxbin,rxpcn,PWOption,* from tbmemberinfo where memCodNum = '71017'

Select MemCodNum from tbmemberinfo where rxgroupid IS NULL AND MemCodNum in (
Select MemCodNum from tbeenrlmembers Where HIC like '3C77C40%') 

Update tbmemberinfo
Set rxgroupid = 123,rxbin = 456,rxpcn = 789,PWOption = 1 
Where MemCodNum in (Select MemCodNum from tbmemberinfo where rxgroupid IS NULL AND MemCodNum in (
Select MemCodNum from tbeenrlmembers Where HIC like '3C77C40%')) */

---------------------------------------------------------------------
-- [ Step 8] Load EAF file2 and once complete Confirm data from EAF as per expectations (5424 records should be present, 904 went into fallout)

--***********************CHECK MENBER DUPE CHECK BEFORE LOAD, MULTIPLE ON. OSB CONFIG ******************* 
 
select  hic,transstatus, t.planid, t.pbpid, t.effectivedate, t.transcode, t.rxgroup, t.rxbin, t.rxpcn, t.osbflag, t.prempart from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename='EAF_02File001_20180101.txt' 
and t.effectivedate='2025-06-01 00:00:00'

Select Error, Applicanthicn,* from ElecAppFile  where filename = 'EAF_02File001_20180101.txt' And IsProcessed = 0

select count(*) from 
 elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename='EAF_02File001_20180101.txt'
and t.effectivedate='2025-06-01 00:00:00'
and transstatus = 2

select count(*) from 
 elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename='EAF_02File001_20180101.txt'
and t.effectivedate='2025-06-01 00:00:00'
and transstatus = 0



--Added by ME - Check New Trans Stauts is 2
select  distinct Left(t.hic,2),transstatus,t.planid, t.pbpid, t.effectivedate, t.transcode, t.rxgroup, t.rxbin, t.rxpcn, t.osbflag, t.prempart from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename='EAF_02File001_20180101.txt'
and t.effectivedate='2025-06-01 00:00:00'

/*
(No column name)	transstatus	planid	pbpid	effectivedate	transcode	rxgroup	rxbin	rxpcn	osbflag	prempart
4C						4		H1001	001	2025-06-01 00:00:00	78			NULL	NULL	NULL	1		NULL
3C						4		H0001	003	2025-06-01 00:00:00	61			NULL	NULL	NULL	NULL	1
6C						4		H1001	001	2025-06-01 00:00:00	78			NULL	NULL	NULL	0		NULL
5C						4		H0001	002	2025-06-01 00:00:00	78			NULL	NULL	NULL	1		NULL
7C						4		H1001	001	2025-06-01 00:00:00	72			111		222		333		NULL	NULL
8C						4		H0001	002	2025-06-01 00:00:00	75			NULL	NULL	NULL	NULL	1
*/

-------------------------------------------------------------------------------------------
/*WORK AROUND
Select OSBFlag,* from tbtransactions where hic like '6C77C40%' and TransCode  = 78
Update tbtransactions Set OSBFlag = 0 where hic like '6C77C40%' and TransCode  = 78 

Insert Into [tbEAM_OSBTransactions](TransID,OSBID)
Select TransID,OSBID = 1 from tbtransactions where hic like '5C77C40%' and TransCode  = 78

Select * from [dbo].[tbEAM_OSBTransactions] Where TransID in (Select TransID from tbtransactions where hic like '6C77C40%' and TransCode  = 78 )

Select * from [dbo].[tbEAM_OSBTypes]
Delete [tbEAM_OSBTypes] Where OSBID Not in (1,2,3,4) */
--------------------------------------------------------------------------------------
-- [Step 9]

update tbtransactions
set transstatus=4
from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename='EAF_02File001_20180101.txt' and t.effectivedate='2025-06-01 00:00:00'


-- [Step 10]

-- use this query to update the transid with plantracking id in the TRR File 3 (Starting from Row #905 in TRR file)
select distinct t.transid, hic
from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic 
where filename='EAF_02File001_20180101.txt' and t.effectivedate='2025-06-01 00:00:00' order by hic

--[Step 11] Load TRR file 3  - 6320 processed and 8 went into Fallout

-- Confirm all transactions are Accepted by CMS

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'
select TransStatus, count(1) as TotalRecords from EAM..tbTransactions t Inner join
EAMWarehouse..[HistoryInputManagerTrrData] W
on W.claimnumber=t.hic Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
where t.effectivedate='2025-06-01 00:00:00'
And
R.requestURI= @FileName
group by transstatus


/*-------------------------------
2C/3c - Plan/PBP Change --> 2C No Plan PBP Change as PWO option being updated via TC 61, 3C Plan/PBP Change
7C - Rx Change TC 72 - > Checked fro RX Update 
8C - PWO - TC 75 - > 75 Chng PWO
4C, 5C,6C, -  OSB  - TC 78 Update OSB */ 
/--------------------------------

---[ Step 12] Verify all records(6320) are present in future table [MemberManagerScheduleFutureUpdate] with Effective date of �2020-06-01�

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'
select * from [MemberManagerScheduleFutureUpdate] where memcodnum in (
select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on W.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2025-06-01 00:00:00')

--- [Step 13] Update date to current so we can run job and see if updates happen 
--- Updating table �MemberManagerScheduleFutureUpdate�

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'
Update MemberManagerScheduleFutureUpdate
set effectivedate='2020-02-01 00:00:00'
from [MemberManagerScheduleFutureUpdate] where memcodnum in (
select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on W.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2025-06-01 00:00:00')

/*----------------------------------------------- Short Tips
Update [EAM].[dbo].[MemberManagerScheduleFutureUpdate] set EffectiveDate = '2020-04-01'
where TransId = '17425'
-------------------------------------------------*/

--- [Step 14] Updating table �tbEnrlSpans� Start and End Date

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'

Update tbenrlspans 
set startdate ='2020-02-01 00:00:00'
from tbenrlspans where startdate ='2025-06-01 00:00:00' and memcodnum in 
(select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on W.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2025-06-01 00:00:00')

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'

Update tbenrlspans 
set EndDate ='2020-01-31 00:00:00'
from tbenrlspans where Enddate ='2025-05-31 00:00:00' and memcodnum in 
(select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on W.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2025-06-01 00:00:00')



---[Step 15] Go to Administration ->Recalculations ->Run Member Rx/OSB Update

---[Step 16] Go to Job processing Status page->Verify �Member Update�, �Member Rx/OSB Update� � Status is Success

-- [Step 17] now run the job and after successful completion of job make sure status in thie futrue table is 2 before it remains 0

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'

select futureupdatetype, effectivedate, statusid, count(1)
from [MemberManagerScheduleFutureUpdate] where memcodnum in (select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on W.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2025-06-01 00:00:00')
group by futureupdatetype, effectivedate, statusid


/*futureupdatetype	effectivedate	statusid	(No column name)
1	2020-02-01 00:00:00	2	896
2	2020-02-01 00:00:00	2	2712
3	2020-02-01 00:00:00	2	2712 */ 


/*
Use PDMMetaData
select * from [dbo].[SchedulerJobTriggers] where id ='abe146b1-162f-4090-9033-190b9baff26a' --GUID
Update [dbo].[SchedulerJobTriggers] Set Status = 3 where id ='ABE146B1-162F-4090-9033-190B9BAFF26A'
*/


---[Step 18] Validate expected result mentioned in Step 3 by running below query

Declare @FileName varchar(100) =  'EFTO.RH1001.DTRRD.D180309.Enrollment_2020_TRR_File3.txt'
Select  Distinct Left(HIC,2) as 'MBI Starting from',planid, pbp, memberstatus, Left(rxid,4) as 'rxid', rxgroupid, rxbin, rxpcn, osbflag, pwoption
--Select  HIC,planid, pbp, memberstatus, Left(rxid,4) as 'rxid', rxgroupid, rxbin, rxpcn, osbflag, pwoption
from tbeenrlmembers e inner join tbmemberinfo m
on e.memcodnum=m.memcodnum where e.memcodnum in (
select memcodnum
from EAMWarehouse..HistoryInputManagerTrrData W
inner join EAM..tbtransactions t
on w.claimnumber=t.hic
Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
And
R.requestURI= @FileName
and t.effectivedate='2025-06-01 00:00:00')

/*
MBI Starting from	planid	pbp	memberstatus	rxid	rxgroupid	rxbin	rxpcn	osbflag		pwoption
2C					H1001	001		2			ANUR	123			456		789			1			1
2C					H1001	001		2			MORE	123			456		789			1			1
3C					H0001	003		2			NULL	NULL		NULL	NULL		1			1
4C					H1001	001		2			ANUR	123			456		789			1			1
4C					H1001	001		2			MORE	123			456		789			1			1
5C					H0001	002		2			NULL	NULL		NULL	NULL		1			3
6C					H1001	001		2			ANUR	123			456		789			0			1
6C					H1001	001		2			MORE	123			456		789			0			1
7C					H1001	001		2			ANUR	111			222		333			1			1
8C					H0001	002		2			NULL	NULL		NULL	NULL		NULL		1
*/
 /*
 1. 3C - OSB 1 in DB but no OSB in UI
 2. 4C - OSB Changes to Dental
 3. 5C - Added OSB to Medical
 */

Select HIC as MBI,PartCPremium,PlanID,PBP, * from tbmemberinfo inner join tbeenrlmembers
on tbmemberinfo.memcodnum = tbeenrlmembers.memcodnum
where tbeenrlmembers.HIC LIKE '2C%'  OR HIC LIKE '3C%'  OR HIC LIKE '4C%'  OR HIC LIKE '6C%' 
Order by tbeenrlmembers.HIC Asc
 
select BASIC_PREMIUM,EFF_DATE, EXP_DATE,planid,PBP,* FROM Member_Premium_Part_C 
where ((planid = 'H1001' and PBP='001') or (planid = 'H0001' and PBP='002') or (planid = 'H0001' and PBP='003') )
and EFF_DATE >= '2020-01-01 00:00:00.000'
 
select OSBPremium,* from [dbo].[tbEAM_OSBConfig] where ((planid = 'H1001' and PBPID='001') or (planid = 'H0001' and PBPID='002') or (planid = 'H0001' and PBPID='003') )

select OSBID,hic as MBI,* from [dbo].[tbEAM_OSBMemberInfo] inner join tbeenrlmembers
on tbEAM_OSBMemberInfo.memcodnum = tbeenrlmembers.memcodnum
where tbeenrlmembers.memcodnum in (select memcodnum from tbeenrlmembers where HIC LIKE '2C%' OR HIC LIKE '3C%'  OR HIC LIKE '4C%' OR HIC LIKE '6C%' )
order by MBI 



----------------------------------------------------------------------------------------------------------------
Select * from tbmemberinfo where MemCodNum in (Select MemCodNum from tbtransactions where hic like '7C77C10%')

Use PDMMetadata
select * from [dbo].[SchedulerJobTriggers] where id ='f87e3fee-8ef4-437f-92b8-e71ee398964d' --GUID
Update [dbo].[SchedulerJobTriggers] Set Status = 3 where id ='F87E3FEE-8EF4-437F-92B8-E71EE398964D'
---------------------------------------------------------------------------------------------------------------

--2C77C00GR51 -> S(4) -> S(1)
--8C77C00GV51 -> R(3) -> N(5)/D(1)
--TRR 1-> EAF 1 -TRR 2 - EAF 2 - TRR 3


