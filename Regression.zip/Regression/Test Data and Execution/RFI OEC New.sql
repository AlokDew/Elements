


Select * from TransactionManagerSepReasonAttestationQuestionMappings
Select * from TransactionManagerSepReasonAttestationQuestionMappings
--select * from TransactionManagerAttestationQuestions
Select * from tbElectiontypes


select S.Code,A.QuestionId,A.PossibleElectionType,E.ElectionType from TransactionManagerSepReasonsCodes S 
Join TransactionManagerSepReasonAttestationQuestionMappings A 
On S.Id = A.ID Join tbElectiontypes E
On A.PossibleElectionType = E.ElectTypeID
Where S.Code = 'MRD'


Select * from TransactionManagerSepReasonsCodes
Select * from TransactionManagerSepReasonAttestationQuestionMappings
Select * from tbElectiontypes where ElectionType = '2'
Select * from TransactionManagerAttestations

------------------------------------
---Check ET Configuration ON/OFF
---Check RFI Letter on Failed BEQ

----OEC File Load 
Select Error, Isprocessed, ApplicantHicn from ElecAppFile  
Where Filename = 'OEC_00000000_FailedBEQETA12_HXXXX.txt'
Order by ApplicantHICN


Select count(isprocessed) from ElecAppFile  
Where IsProcessed = 1 
And Filename = 'OEC_00000000_FailedBEQETA01_HXXXX.txt'

---Verify OEC SEP ReasonCode ElecApp Vs Transactions
Select Distinct T.HIC,M.SepReason as OECSepReasonCode, E.SEPReasonCode
From Tbtransactions T Join tbmemberinfo M
On T.MemCodNum = M.MemCodNum Left Join TB_EAM_SEPS_REASON R
On T.SEPSReason = R.Reason_ID Join ElecAppFile E
On T.HIC = E.ApplicantHICN 
Where E.FileName = 'OEC_00000000_FailedBEQETA01_HXXXX.txt'

-----Verify same on Transaction

Select tr.HIC,tr.Effectivedate,tr.TransStatus,r.Code,a.SequenceNo as 'Priority Order',
m.PossibleElectionType,e.ElectionType as 'Expected ET as Priority',tr.ElectionType as 'Actual ET as Priority',
tr.Incomplete, tr.MissingItem from TransactionManagerSepReasonAttestationQuestionMappings m
join TransactionManagerSepReasonsCodes r on m.SepReasonCodeId = r.Id
join TransactionManagerAttestations a on a.SepReasonCodeId = m.SepReasonCodeId
join tbElectionTypes e on e.ElectTypeID = m.PossibleElectionType 
join tbTransactions tr on tr.TransID = a.TransId
where a.TransId in (select transid from tbtransactions where hic like '8B77C00AD%')
group by a.TransId, tr.effectivedate,tr.transstatus,a.SequenceNo,tr.HIC,r.Code,e.ElectionType,
tr.ElectionType,tr.Incomplete, tr.missingitem,m.PossibleElectionType
order by a.TransId,a.SequenceNo

---Export BEQ file H0001,H1001,S2001

--Prepare BQN File

Exec BEQResponse_Generator '8B77C00AD%',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=N;
MedPartAEntStartDate=20190201;
MedPartBEntStartDate=20190201;
PartDEligibilityStartDate=20190601;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D' 

---Import File BQN

Select tr.HIC,tr.Effectivedate,I.DOB, tr.TransStatus,r.Code,a.SequenceNo as 'Priority Order',
m.PossibleElectionType,tr.ElectionType as 'Actual ET as Priority',e.ElectionType as 'Trans ET as Priority',
tr.Incomplete, tr.MissingItem from TransactionManagerSepReasonAttestationQuestionMappings m
join TransactionManagerSepReasonsCodes r on m.SepReasonCodeId = r.Id
join TransactionManagerAttestations a on a.SepReasonCodeId = m.SepReasonCodeId
join tbTransactions tr on tr.TransID = a.TransId
join tbElectionTypes e on e.ElectTypeID = tr.ElectionType 
join tbMemberInfo I on I.MemCodNum = tr.MemCodNum
where a.TransId in (select transid from tbtransactions where hic like '8B77C00AD%')
group by a.TransId, tr.transDOB,I.DOB,tr.effectivedate,tr.transstatus,a.SequenceNo,tr.HIC,r.Code,e.ElectionType,
tr.ElectionType,tr.Incomplete, tr.missingitem,m.PossibleElectionType
order by a.TransId,a.SequenceNo

--- RFI Letter Configuration
--2019/2020/2022


select * from tbElectionPeriod  - 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 16, 19, 20

--- Received By Date Verification
/*8A77C00AD01
In Queued Letter - 01/31/2021
From Func - 01/012021 */

Select dbo.fnPDM_Get_DueDate (ISNULL(3,Null),Null,Null,'1965-01-15 00:00:00.000',GetDate(),'2019-02-01 00:00:00')

/*8A77C00AD02
In Queued Letter - 01/25/2021
From Func - 01/25/2021 */

Select dbo.fnPDM_Get_DueDate (ISNULL(19,Null),Null,Null,'1966-01-15 00:00:00.000',GetDate(),'2020-02-01 00:00:00')

/*8A77C00AD03
In Queued Letter - 01/26/2021
From Func - 01/26/2021 */

Select dbo.fnPDM_Get_DueDate (ISNULL(9,Null),'2019-02-01 00:00:00.000','2019-02-01 00:00:00.000','1967-01-15 00:00:00.000',GetDate(),'2020-04-01 00:00:00')

/*8A77C00AD04
In Queued Letter - 01/31/2021
From Func - 01/31/2021 */

Select dbo.fnPDM_Get_DueDate (ISNULL(4,Null),Null,Null,'1968-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

Select * from tbElectionPeriod

/*8A77C00AD05
In Queued Letter - 01/31/2021
From Func - 01/31/2021 */

Select dbo.fnPDM_Get_DueDate (ISNULL(2,Null),Null,Null,'1969-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD06
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(4,Null),Null,Null,'1970-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD07
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(8,Null),Null,Null,'1971-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD08
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(8,Null),Null,Null,'1972-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD09
In Queued Letter - 01/25/2021
From Func - 01/25/2021 */

Select dbo.fnPDM_Get_DueDate (ISNULL(8,Null),Null,Null,'1973-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD10
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD11 --Done
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(7,Null),Null,Null,'1975-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD12
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD13
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD14
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD15
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD16
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD17
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD18
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD19
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD20
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD21
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD22
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')

/*8A77C00AD23
In Queued Letter - 2021-01-31 00:00:00
From Func - 2021-01-31 00:00:00 */

Select dbo.fnPDM_Get_DueDate (ISNULL(20,Null),Null,Null,'1974-01-15 00:00:00.000',GetDate(),'2022-01-01 00:00:00')





sp_helptext fnPDM_Get_DueDate

Select * from tbtransactions where hic = ''