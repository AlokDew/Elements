Select multiple from tbplan_pbp

Select * from tbtransactions where hic like '3A77C00AZ%'

Select Error,ApplicantHICN,SepReasonCode,SubmitDate,SubmitTime,EnrollmentPlanYear
From ElecAppFile where ISProcessed = 1 And FileName = 'OEC_00000000_SCCPRemETYOFF01_HXXXX1.txt'

Select EffectiveDate,EndDate,PremC,PremD from tbPlanPBPSegPremSpans
where  PlanID = 'H1003' and PBPID = '011' and EffectiveDate In ('2022','2020','2021')

Select * from    [MEMBER_PREMIUM_PART_C] where planid = 'H1003' and EFF_Date like '%2022%'
Select * from    [BID_RATES_PART_D] where planid = 'H1003' and EFF_Date like '%2022%'
Select * from   [BID_RATES_PART_C] where planid = 'H1003' and EFF_Date like '%2022%'
Select * from  tbLISCoPays
Select * from  tbPlanPBPSegPremSpans where planid = 'H1003' and EffectiveDate like '%2022%'

Select T.HIC,TransStatus,ApplicationDate,T.EffectiveDate,S.StartDate as SpanStart, S.EndDate as SpanEnd,PartC as TransPartC,PartD as TransPartD, M.PartCPremium as MemPartC, M.PartDPRemium as MemPartD
From Tbtransactions T Join tbmemberinfo M On T.MemCodNum = M.MemCodNum Join ElecAppFile E
On T.HIC = E.ApplicantHICN Join tbENRLSpans  S
On T.HIC = S.HIC															
Where E.FileName = 'OEC_00000000_SCCPRemETYOFF01_HXXXX1.txt'
And TransStatus = 0
Order by HIC

Update tbtransactions set transstatus = 7 where hic like '3A77C00AZ%'	
																		
--Select * from [dbo].[tbEAM_OSBConfig] WHere PLANID = 'PDM01'
--OSB � H1003/011 Medical and Dental 2019 -2019 10.00$
--OSB � H1003/011 Medical 2020-2020 15$
--OSB � H1003/011 Medical 2021-2021 20$

Select * from  [dbo].[tbEAM_OSBConfig] Where PlanID = 'H1003'

Select * from [dbo].[PlanManagerOsbDetail] M JOIN tbEAM_OSBConfig c ON M.ID = C.OSBID
WHERE M.TypeId IN (1,2,3,4) AND C.PlanID = 'H1003'and C.PBPID = '011'
AND OSBendDate = '2025-12-31 00:00:00.000'


Insert into [dbo].[tbEAM_OSBConfig] values ('H1003','011',5,10,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1003','011',22,10,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1003','011',5,15,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1003','011',5,20,'2022-01-01','2022-12-31','tmsadmin','2020-04-01')

Select HIC,EffectiveDate,OSBFlag,PartC,PartD from tbTransactions
Where HIC Between '3A77C00AZ01' And '3A77C00AZ02' 
															

Select T.HIC,TransStatus,ApplicationDate,T.EffectiveDate,S.StartDate as SpanStart, S.EndDate as SpanEnd,PartC as TransPartC,PartD as TransPartD, M.PartCPremium as MemPartC, M.PartDPRemium as MemPartD
From Tbtransactions T Join tbmemberinfo M On T.MemCodNum = M.MemCodNum Join tbENRLSpans  S
On T.HIC = S.HIC
Where T.HIC In ('3A77C00AZ03','3A77C00AZ04')										
Order by HIC

Select T.HIC,TransStatus,ApplicationDate,T.EffectiveDate,S.StartDate as SpanStart, S.EndDate as SpanEnd,PartC as TransPartC,PartD as TransPartD, M.PartCPremium as MemPartC, M.PartDPRemium as MemPartD
From Tbtransactions T Join tbmemberinfo M On T.MemCodNum = M.MemCodNum Join tbENRLSpans  S
On T.HIC = S.HIC
Where T.HIC In ('3A77C00AZ05','3A77C00AZ06','3A77C00AZ07')															
Order by HIC

