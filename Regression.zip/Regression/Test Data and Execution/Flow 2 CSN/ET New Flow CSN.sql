
Exec spEAM_GetSNPDetailedConfig

Select error,IsProcessed, SEPReasonCode,ContractID,PlanID,ApplicantHICN from ElecAppfile where filename = 'OEC_01012021_ETFlow2Y01_CSN.txt'

select * from tb_eam_seps_reason where IsActive = 1

Select HIC,ElectionType,SEPSReason from tbtransactions where hic like '7C35C96AD0%'

Select HIC, TransCode,TransStatus,Planid,PBPid,EffectiveDate,ElectionType,SEPSReason
From tbtransactions
Where HIC Between '7C35C96AD01' AND '7C35C96AD04'


select * from TransactionManagerSepReasonAttestationQuestionMappings

Exec BEQResponse_Generator '7C35C96AD01,7C35C96AD02,7C35C96AD03,7C35C96AD04',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20100101;
MedPartBEntStartDate=20100101;
PartDEligibilityStartDate=20180101;
NotLawfulPresenceEndDate10=20120101;'


select sepsreason,electiontype,EffectiveDate,ReceiptDate,TransStatus,* from tbtransactions
where hic like '7C35C96AD0%'

Update tbtransactions set snpstatustype = Null, onholdreasonid = null where hic like '7AA1AA1AA%'
 