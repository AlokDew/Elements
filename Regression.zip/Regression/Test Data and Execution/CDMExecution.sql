Select * from BatchDetails order by batchid desc 

select * from BatchDetails order by ProcessDate desc
 
select * from FrontEndRejects where BatchID= '3981'
 
select * from Claims where hicnumber = 'MEM377406'

--The sum of the data results displayed using the below queries should be same or equal to data details displayed under Claims Status Summary section.

Select * from [dbo].[Claims]
where BatchID in (Select BatchID from [dbo].[BatchDetails] where fileName like 'Claim_20190106_P_O_ClaimsICD9_ICD10.Claims')

select * from Clusters 
where ClaimsID in (select ClaimsId from [dbo].[Claims] where BatchID in (Select BatchID from [dbo].[BatchDetails]
where fileName = 'Claim_20190106_P_O_ClaimsICD9_ICD10.Claims'))

select ErrorCodes,ClaimRejectType,* from FrontEndRejects
where BatchID in (Select BatchID from [dbo].[BatchDetails] where fileName like 'Claim_20190106_P_O_ClaimsICD9_ICD10.Claims')

select * from [dbo].[tbCMSProviderSpecialtyAcceptablePeriod] where SpecialtyCode = '01'

 
update tbCMSProviderSpecialtyAcceptablePeriod set Acceptable = 0 where SpecialtyCode = '01'


select * from Clusters
Select * from [dbo].[FrontEndErrors]
Select * from [dbo].[ClusterErrors]

Select * from [dbo].[InvalidDupeClaims]
Select status, * from clusters where clustersid = '6859018'

Select DeleteIndicator, DeleteSourceID, FalloutReason, ProcessIndicator, * from [dbo].[ExportManagerClusterDeleteExtract] 


Select Status, * from clusters order by StatusDate desc


Select * from [dbo].[Clusters] where HicNumber = 'HICN066600' order by ModifyDate desc

select * from Clusters where hicnumber = 'HICN066600' order by ModifyDate asc
select * from Status
select * from Claims where claimsid = '18774942'


inner Join 
[dbo].[BatchDetails] Bat on Bat.BatchID = C.BatchId 
Left Outer Join
[dbo].[ClusterErrors] CE on CE.ClustersID = C.ClustersID
where --C.HICNumber = 'HICN055500'
C.ICDVersion = '1' --1 for ICD10 codes and <> '1' for ICD9 Codes
and C.ProviderType IN('P','I','O','E')
and C.FromDate > =  '2015-01-01 00:00:00.000'
and C.ThroughDate < '2015-01-31 00:00:00.000'
--and C.BatchID in (Select BatchID from BatchDetails where filename = 'Claim_20180101_P_O_ClaimsICD9_ICD10.Claims')
and C.status = '1'
