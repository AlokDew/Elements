GO
USE CMSBEQ
Declare @MBI varchar(100) = '5G77C00AA06'
Declare @AddressStartDate varchar(100) = '2020-01-01'; 
Declare @City varchar(100) = 'SCHENECTADY';
Declare @PostalStateCode varchar(100) = 'NY';
Declare @ZipCode varchar(100) = '12345';
Declare @AddressType varchar(100) = '1';  -- 1 Mailing/2 Residence

Declare @FirstName varchar(100) = 'QAD6'
Declare @MiddleInitial varchar(100) = 'A'
Declare @LastName varchar(100) = 'TEST6'
Declare @BirthDate varchar(100) = '1961-01-01'
Declare @Gender varchar(100) = '2'

Declare @EnrollmentDate varchar(100) = '2020-01-01'
Declare @ContractNumber varchar(100) = 'H0002'
Declare @PlanBenefitPackageNumber varchar(100) = '006'
Declare @ProgramType varchar(100) = 1 --'1 - MA/Part C only'  --1 - MA/Part C only, 2 - PDP/Part D only, 3 - MA & PDP
Declare @PlanType varchar(100) = '01'  --- 1 Cuurent / 2 Prior
Declare @SourceType varchar(100) = ''
Declare @SegmentNumber varchar(100) = ''

Declare @EntitlementReason varchar(100) = 'B'
Declare @EntitlementReasonChangeDate varchar(100) = '2019-01-01'

Declare @StartDate varchar(100) = '2020-01-01'
Declare @StopDate varchar(100) = '2020-01-31'
Declare @CopaymentLevel varchar(100) = '3' --1.00
Declare @PremiumSubsidyPercent varchar(100) = '100' --100.00

Declare @PartAEntitlementDates varchar(100) = '2019-01-01'
Declare @PartBEntitlementDates varchar(100) = '2019-02-01'
Declare @PartDEligibilityDates varchar(100)= '2019-01-01'
--Declare @PartDEnrollmentDates varchar(100)= '20110201'
--Declare @RetireeDrugCoverage varchar(100)= ''
--Declare @IncarcerationDates varchar(100)= ''
Declare @NotLawfulPresenceStart varchar(100)= '2018-02-01'
Declare @NotLawfulPresenceEnd varchar(100)= '2018-12-31'
--Declare @CaraDates varchar(100) = ''

Declare @CodeName varchar(100) = 'MATCHED'
Declare @Code varchar(100) = '000'
Declare @Description varchar(100) = 'Matched Beneficary'

--Declare @UCStartDate varchar(100) = '2019-12-01'
--Declare @UCMonthsCount varchar(100) = 1.00
--Declare @UCStatus varchar(100) = 'C'



--===== BeqAddressInfo ====

--Select * from [BeqAddressInfo] where [MedicareBeneficiaryIdentifier] = @MBI
--Delete From [BeqAddressInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

SET IDENTITY_INSERT BeqAddressInfo ON

INSERT [BeqAddressInfo] ([Id], [MedicareBeneficiaryIdentifier], [AddressStartDate], [City], [PostalStateCode], [ZipCode], [AddressType])
VALUES (ABS(CHECKSUM(NEWID())), @MBI, @AddressStartDate, @City, @PostalStateCode, @ZipCode, 1)


SET IDENTITY_INSERT BeqAddressInfo OFF

SET IDENTITY_INSERT BeqBeneficiaryInfo ON


--===== [BeqBeneficiaryInfo] ====

--Select * from BeqBeneficiaryInfo where [MedicareBeneficiaryIdentifier] = @MBI  
--Delete From [BeqBeneficiaryInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BeqBeneficiaryInfo] ([Id], [MedicareBeneficiaryIdentifier], [FirstName], [MiddleInitial], [LastName], [BirthDate], [DeathDate], [Gender], [DeathDateProof], [BeneficiaryKey], [LatestSpecialEnrollmentPeriodUseDate], [HasMedicaid])
VALUES (ABS(CHECKSUM(NEWID())), @MBI, @FirstName, @MiddleInitial, @LastName, @BirthDate, Null, @Gender, Null, ABS(CHECKSUM(NEWID())), Null, 1)

SET IDENTITY_INSERT BeqBeneficiaryInfo OFF

SET IDENTITY_INSERT BeqEnrollmentInfo ON

--===== [BeqEnrollmentInfo] ====

--Select * from BeqEnrollmentInfo where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [BeqEnrollmentInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BeqEnrollmentInfo] ([Id], [EnrollmentDate], [DisenrollmentDate], [ContractNumber], [PlanBenefitPackageNumber], [ProgramType], [PlanType], [SourceType], [IsEmployerGroupHealthPlan], [AddedDateTime], [SegmentNumber], [SubmittingContractNumber], [MedicareBeneficiaryIdentifier], [EnrollmentType])
VALUES (ABS(CHECKSUM(NEWID())), @EnrollmentDate, Null, @ContractNumber, @PlanBenefitPackageNumber, @ProgramType, @PlanType, @SourceType, 0, GetDate(), @SegmentNumber, @ContractNumber, @MBI, 1)

SET IDENTITY_INSERT BeqEnrollmentInfo OFF

SET IDENTITY_INSERT BeqEntitlementReasonInfo ON

--===== [BeqEntitlementReasonInfo] ====

--Select * from [BeqEntitlementReasonInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [[BeqEntitlementReasonInfo]] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BeqEntitlementReasonInfo] ([Id], [EntitlementReason], [EntitlementReasonChangeDate], [MedicareBeneficiaryIdentifier])
VALUES (ABS(CHECKSUM(NEWID())), @EntitlementReason, @EntitlementReasonChangeDate, @MBI)

SET IDENTITY_INSERT BeqEntitlementReasonInfo OFF

SET IDENTITY_INSERT BeqLowIncomeSubsidyInfo ON

--===== [BeqLowIncomeSubsidyInfo] ====

--Select * from [BeqLowIncomeSubsidyInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [[BeqLowIncomeSubsidyInfo]] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BeqLowIncomeSubsidyInfo] ([Id], [StartDate], [StopDate], [CopaymentLevel], [PremiumSubsidyPercent], [InstitutionalStatus], [MedicareBeneficiaryIdentifier])
VALUES (ABS(CHECKSUM(NEWID())), @StartDate, @StopDate, @CopaymentLevel, @PremiumSubsidyPercent, '1', @MBI)

SET IDENTITY_INSERT BeqLowIncomeSubsidyInfo OFF

SET IDENTITY_INSERT BEQMedicareCardInfo ON

--===== [BEQMedicareCardInfo] ====

--Select * from [BEQMedicareCardInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [BEQMedicareCardInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BEQMedicareCardInfo] ([Id], [CardRequestDate], [MedicareBeneficiaryIdentifier]) VALUES (ABS(CHECKSUM(NEWID())), '2020-01-01', @MBI)

SET IDENTITY_INSERT BEQMedicareCardInfo OFF

SET IDENTITY_INSERT BeqPeriodInfo ON

--===== [BeqPeriodInfo] ====

--Select * from [BeqPeriodInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [BeqPeriodInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), @PartAEntitlementDates, '', @MBI, 1)
INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), @PartBEntitlementDates, '', @MBI, 2)
INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), @PartDEligibilityDates, '', @MBI, 3)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), @PartAEntitlementDates, '', @MBI, 4)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), @PartAEntitlementDates, '', @MBI, 5)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), @PartAEntitlementDates, '', @MBI, 6)
INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
VALUES (ABS(CHECKSUM(NEWID())), @NotLawfulPresenceStart, @NotLawfulPresenceEnd, @MBI, 7)
--INSERT [BeqPeriodInfo] ([Id], [StartDate], [StopDate], [MedicareBeneficiaryIdentifier], [PeriodType]) 
--VALUES (ABS(CHECKSUM(NEWID())), @PartAEntitlementDates, '', @MBI, 8)


--===== [BEQResponseCodeInfo] ====

--Select * from [BEQResponseCodeInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [BEQResponseCodeInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

SET IDENTITY_INSERT BeqPeriodInfo OFF

SET IDENTITY_INSERT [BEQResponseCodeInfo] ON

INSERT [BEQResponseCodeInfo] ([Id], [MedicareBeneficiaryIdentifier], [CodeName], [Code], [Description]) 
VALUES (ABS(CHECKSUM(NEWID())), @MBI, @CodeName, @Code, @Description)

SET IDENTITY_INSERT [BEQResponseCodeInfo] OFF

SET IDENTITY_INSERT BeqStateCountyInfo ON

--===== [BeqStateCountyInfo] ====

--Select * from [BeqStateCountyInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
--Delete From [BeqStateCountyInfo] where [MedicareBeneficiaryIdentifier] = @MBI 

INSERT [BeqStateCountyInfo] ([Id], [SsaCounty], [SsaState], [FipsCounty], [FipsState], [ZipCode], [MedicareBeneficiaryIdentifier])
VALUES (ABS(CHECKSUM(NEWID())), '000', 33, 198, 12, 7666, @MBI)

SET IDENTITY_INSERT BeqStateCountyInfo OFF

--SET IDENTITY_INSERT [BEQUncoveredMonthsInfo] ON

----===== [BEQUncoveredMonthsInfo] ====

----Select * from [BEQUncoveredMonthsInfo] where [MedicareBeneficiaryIdentifier] = '1EG4TE5MK75'  
----Delete From [BEQUncoveredMonthsInfo] where [MedicareBeneficiaryIdentifier] = @MBI

--INSERT [BEQUncoveredMonthsInfo] ([Id], [StartDate], [MonthsCount], [Status], [MedicareBeneficiaryIdentifier])
--VALUES (ABS(CHECKSUM(NEWID())), @UCStartDate, CAST(@UCMonthsCount AS Decimal(18, 2)), @UCStatus, @MBI)


--SET IDENTITY_INSERT [BEQUncoveredMonthsInfo] OFF

--GO
--SET IDENTITY_INSERT BeqAddressInfo OFF 
--SET IDENTITY_INSERT BeqBeneficiaryInfo OFF
--SET IDENTITY_INSERT BeqEnrollmentInfo OFF
--SET IDENTITY_INSERT BeqEntitlementReasonInfo OFF
--SET IDENTITY_INSERT BEQMedicareCardInfo OFF
--SET IDENTITY_INSERT BeqPeriodInfo OFF
--SET IDENTITY_INSERT BEQResponseCodeInfo OFF
--SET IDENTITY_INSERT BeqStateCountyInfo OFF
--SET IDENTITY_INSERT BEQUncoveredMonthsInfo OFF
--SET IDENTITY_INSERT BeqLowIncomeSubsidyInfo OFF