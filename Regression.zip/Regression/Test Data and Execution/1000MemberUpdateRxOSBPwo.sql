
Select * from tbPlanPBPSegPremSpans Where PlanID In ('H0001','H1001') And EffectiveDate like '%2021%'

Select * from Member_Premium_Part_C Where PlanID In ('H0001','H1001') And EFF_DATE like '%2022%'

Delete from [dbo].[tbMMPMemberLoad]

select transstatus,* from tbtransactions where HIC like '%5F99C011%'

select transstatus,* from tbtransactions where HIC like '%5F99C012%'


Delete [dbo].[tbEGWPPlanPbpAssociation] 
 
update tbplan_pbp set multiple = 0  


Delete from [EAM].[dbo].[tbMMPMemberLoad] where (((planid = 'H1001' and PBPid = '001') or (planid = 'H0001' and PBPid in ('001', '002'))) and EffectiveDate >='2020-01-01')

Select * From tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where idtype = 3 and pbptype = 0

Select * from tbPlans
Select multiple,* from tbplan_pbp
Update tbplan_pbp Set pbptype = 0 where PlanID = 'H0001' and PBPID = '001'

Select * from [dbo].[PlanManagerOsbDetail] M JOIN tbEAM_OSBConfig c ON M.ID = C.OSBID WHERE M.TypeId IN (1,2,3,4) AND C.PlanID = 'H1004'and C.PBPID = '016'AND OSBendDate = '2025-12-31 00:00:00.000'

select * from PlanManager3RxDetail  where planid='H1004'

select  transstatus, t.planid, t.pbpid, t.effectivedate, t.transcode,t.rxid, t.rxgroup, t.rxbin, t.rxpcn, t.osbflag, t.prempart from elecappfile e
inner join tbtransactions t
on e.applicanthicn=t.hic
where filename= 'EAF_File1_20200501.txt' 
and t.effectivedate='2025-01-01 00:00:00'


update tbtransactions set transstatus='4' where HIC like '%5F99C011%'  and transstatus='0' 
update tbtransactions set transstatus='4' where HIC like '%5F99C012%'  and transstatus='0'



select transid ,HIC,* from tbtransactions where HIC like '%5F99C011%'  and transstatus='4' 
select transid ,HIC,* from tbtransactions where HIC like '%5F99C012%'  and transstatus='4'


Declare @FileName varchar(100) = 'EFTO.RH1001.DTRRD.D241220.TRRCMS1_TRR12.txt'

select TransStatus, count(1) as TotalRecords from EAM..tbTransactions t Inner join
EAMWarehouse..[HistoryInputManagerTrrData] W
on W.claimnumber=t.hic Inner join
EAMWarehouse..[HistoryInputManagerEntities] E 
On W.EntityId = E.EntityId Inner join
EAMWarehouse..[HistoryInputManagerRequests] R
On E.RequestId = R.Requestid
where t.effectivedate='2025-01-01 00:00:00'
And
R.requestURI= @FileName
group by transstatus

select RXID,RxGroupID,RxBin,RxPCN,OSBflag,PWOption,PartCPremium,PartDPremium,LastChangedById,* from tbMemberInfo where memcodnum in (select memcodnum from tbtransactions where HIC like '%5F99C011%' )
 
select RXID,RxGroupID,RxBin,RxPCN,OSBflag,PWOption,PartCPremium,PartDPremium,LastChangedById,* from tbMemberInfo where memcodnum in (select memcodnum from tbtransactions where HIC like '%5F99C012%' )



select * from MemberManagerScheduleFutureUpdate where memcodnum in (select memcodnum from tbtransactions where HIC like '%5F99C011%')
  
select * from MemberManagerScheduleFutureUpdate where memcodnum in (select memcodnum from tbtransactions where HIC like '%5F99C012%')


Update MemberManagerScheduleFutureUpdate
set effectivedate='2020-02-01 00:00:00'
where memcodnum in (select memcodnum from tbtransactions where HIC like '%5F99C011%')
 
Update MemberManagerScheduleFutureUpdate
set effectivedate='2020-02-01 00:00:00'
where memcodnum in (select memcodnum from tbtransactions where HIC like '%5F99C012%')


Update tbenrlspans 
set startdate ='2020-02-01 00:00:00'
from tbenrlspans where startdate ='2025-01-01 00:00:00' and memcodnum in 
(select memcodnum from tbtransactions where HIC like '%5F99C011%')
 
Update tbenrlspans 
set startdate ='2020-02-01 00:00:00'
from tbenrlspans where startdate ='2025-01-01 00:00:00' and memcodnum in 
(select memcodnum from tbtransactions where HIC like '%5F99C012%')
 


Update tbenrlspans 
set EndDate ='2020-01-31 00:00:00'
from tbenrlspans where Enddate ='2024-12-31 00:00:00' and memcodnum in 
(select memcodnum from tbtransactions where HIC like '%5F99C011%')
 
 
Update tbenrlspans 
set EndDate ='2020-01-31 00:00:00'
from tbenrlspans where Enddate ='2024-12-31 00:00:00' and memcodnum in 
(select memcodnum from tbtransactions where HIC like '%5F99C012%')
 



4F99C011003 , 4F99C012000

select RXID,RxGroupID,RxBin,RxPCN,OSBflag,PWOption,PartCPremium,PartDPremium,LastChangedById,* from tbMemberInfo where memcodnum in (select memcodnum from tbtransactions where HIC like '%1F99C011%' )
 
select RXID,RxGroupID,RxBin,RxPCN,OSBflag,PWOption,PartCPremium,PartDPremium,LastChangedById,* from tbMemberInfo where memcodnum in (select memcodnum from tbtransactions where HIC like '%1F99C012%' )




select PlanID,PBP,CurrentEffDate,TermDate,* from tbeenrlmembers where HIC like '%5F99C011%' and CurrentEffDate = '2020-02-01 00:00:00.000'
select PlanID,PBP,CurrentEffDate,TermDate,* from tbeenrlmembers where HIC like '%5F99C012%' and CurrentEffDate = '2020-02-01 00:00:00.000'



select * from MemberManagerScheduleFutureUpdate where memcodnum in (select memcodnum from tbtransactions where HIC like '%4F99C011%')
And
Statusid = 0


select * from MemberManagerScheduleFutureUpdate where memcodnum in (select memcodnum from tbtransactions where HIC like '%4F99C011%')
Update MemberManagerScheduleFutureUpdate Set StatusId = 0 where memcodnum in (select memcodnum from tbtransactions where HIC like '%4F99C011%')
