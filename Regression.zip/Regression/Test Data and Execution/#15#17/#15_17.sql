
Select Applicanthicn, SepsReason,SepReasonCode,IsProcessed from elecappfile 
where filename in ('EAF_SEPS_ET_#15#17_FlowY01_20210101.txt','OEC_01012021_SEPSY01_AttestQuestion15and17.txt')
order by ApplicantHICN

Select T.HIC,T.TransStatus,T.EffectiveDate,T.ApplicationDate, T.ElectionType,T.SEPSReason,M.SEPReason
From tbtransactions T Join tbmemberinfo M
On T.MemcodNum = M.Memcodnum
Where T.hic like '7B77C00AA0%'

select * from TB_EAM_SEPS_REASON where SepsReasonCodeNumber in (11,12,35)

Select  sepreason,* from tbmemberinfo

Select sepreason  * from tbtransactions 


select * from [dbo].[TransactionManagerSepReasonsCodes] where Description like '%OTH%'

select * from TransactionManagerAttestations where SepReasonCodeId = 11

select * from [dbo].[TransactionManagerAttestationQuestions]

select * from TransactionManagerSepReasonAttestationQuestionMappings

[ENRL_Insert_SEPReasonCode_InsertDate] 11181,'LT2,CSN,LPI'

select * from fn_EAM_GetAllValidSEPReasonCodeWithOrder ('OEP,NEW,LT2,CSN,LPI')



SELECT * FROM [dbo].[tbEGWPPlanPbpAssociation] 
Delete FROM [dbo].[tbEGWPPlanPbpAssociation]

Exec BEQResponse_Generator '7B77C00AA01,7B77C00AA02,7B77C00AA03,7B77C00AA06,7B77C00AA07,7B77C00AA08',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20100101;
MedPartBEntStartDate=20100101;
PartDEligibilityStartDate=20180101;
NotLawfulPresenceEndDate10=20120101;' 


Exec BEQResponse_Generator '7B77C00AA04,7B77C00AA05,7B77C00AA09',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
PartCDPlanType=28;
MedPartAEntStartDate=20100101;
MedPartBEntStartDate=20100101;
PartDEligibilityStartDate=20180101;
NotLawfulPresenceEndDate10=20120101;'


select * from tbSepsReasonCodeAndPlanTypeConfiguration