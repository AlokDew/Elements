--To See, Trasnaction Status 
select TransStatus,Programsource,* from tbTransactions where HIC='7C77C00HD63'
----------------------------------------------------------------------------------
--Excel Formula
=IF(ISERROR(VLOOKUP(A2,$B$2:$B$50,1,FALSE)),FALSE,TRUE)

--VLOOKUP(Col Name for which value you are looking for its corresponding value, Sheet Name where those corresponding value lying with All its range from one to last corner, col Num where your corresponding value actually lying. )
=VLOOKUP(A1,Sheet4!A1:D200,4,FALSE)

'--------------------FILE SHARE -----------------
\\ASP-TMS-FILE-01\FileShare\Env-SetUp
'-------------------------------------------------

---------------------------------------------------
--PDM Meta Data ConfigurationManagerTcTrcActionMap

Select * from [dbo].[FrameworkManagerExternalSystem]
----------------------------------------------------

Select * from tbDBUpdates

-----------------------------------------------------

--To Genearte BEQ Response
exec BEQResponse_Generator '7C77C00DW81', 
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20110201;
MedPartBEntStartDate=20110201;
PartDEnrEffDateEmpSubsStartDate1=20110201;
PartDEligibilityStartDate=20110201' 

--To Genearte BEQ Response with LIS
exec BEQResponse_Generator '7C77C00PD85', 
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20180101;
MedPartBEntStartDate=20180101;
PartDEnrEffDateEmpSubsStartDate1=20180101;
PartDEligibilityStartDate=20180101;

DeemedLISEffDate1=20180101;
DeemedLISEndDate1=20181231;
CopayLelelId1=2;
PartDPremiumSubsidyPercent1=100;

DeemedLISEffDate2=20190101;
DeemedLISEndDate2=20191231;
CopayLelelId2=4;
PartDPremiumSubsidyPercent2=100'

'------------------------------------
exec BEQResponse_Generator '7C77C01PT56',
 'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=19970401;
MedPartBEntStartDate=19970401;
PartDEligibilityStartDate=20060101;
DeemedLISEffDate1=20190201;
DeemedLISEndDate1=20190228;
PartDPremiumSubsidyPercent1=075;
CopayLelelId1=4'

--------------------------------------------
-- SQL Member/Transaction alll records

Select * from tbMemberInfo MI
Inner Join tbEEnrlmembers EM
On EM.MemCodNum = MI.MemCodNum
Inner Join tbtransactions T 
On T.HIC = EM.HIC
Where T.HIC = '7C77C00D101'

'--------------------------------------------
'--Premium LIS Records
'--------------------------------------------
Select OtherInsurance,BillAmount,PWOption,PartCPremium,PartDPremium,EmplSubOverride,EmployerName,EmplGroupNum,PartDSubsLevel,LowIncCoPayCat,LowIncomeCoPayEffectiveDate,
PartDLateEnrollmentPenaltyAmount,PartDLateEnrollmentPenaltyWaivedAmount,PartDLateEnrollmentPenaltySubsidyAmount,LowIncomePartDPremiumSubsidyAmount,
EGPaysLEP,BillingEffDate,LowIncomeCoPayEndDate,MI.OSBFlag,CreditableCover,UncoveredMon
from tbMemberInfo MI
Inner Join tbEEnrlmembers EM
On EM.MemCodNum = MI.MemCodNum
Inner Join tbtransactions T 
On T.HIC = EM.HIC
Where T.HIC = '7C77C00SX20'

Select * from [dbo].[tbEAM_OSBMemberInfo] Where MemCodNum in ( Select MemCodNum from tbtransactions where HIC = '7C77C00SX20')
------------------------------------------------------
	Member Transaction Audit
------------------------------------------------------
Use EAM
Select
(Select Count(*) from [EAMWarehouse].[Audit].[TransactionLevel_Audit] T
Where T.MemCodNum in (Select MemCodNum from EAM.dbo.tbEENRLMembers where hic = 'NEWMBICHAN')) 
+
(Select Count(*) from [EAMWarehouse].[Audit].[MemberLevel_Audit] M
Where M.MemCodNum in  (Select MemCodNum from EAM.dbo.tbEENRLMembers where hic = 'NEWMBICHAN')) as Total_Audit_Records

--Audit Job Clean up
select * from [Audit].[AuditJob] order by 1 desc
Select * from [Audit].[AuditJobRunInfo] where endtime is null order by 1 desc
--delete from [Audit].[AuditJobRunInfo] where endtime is null 

-------------------------------------------------
-TC90
-------------------------------------------------
Update tbtransaction90
Set ImplementationDate = '2019-07-20 00:00:00.000', PrescriberLimitation = 0, PharmacyLimitation = 0
Select * from tbtransactions where hic = '7C77E00CE04'

Select * from tbtransaction90 where transId = '26232'

'--------------------------------------------
'--Premium LIS Records
'--------------------------------------------
'Verify existing LIS records
select * from tbmemberinfolislog
where memcodnum = (select memcodnum from tbeenrlmembers where hic = '7C77C01PT54')

'Verify Current Record
select * from tbmemberinfolislog
where memcodnum = (select memcodnum from tbeenrlmembers where hic = '7C77C01PT54')
and valid=1 and (getdate() between LowIncomeCoPayEffectiveDate   and LowIncomeCoPayEndDate)
'---------------------------------------------


Member_Premium_Part_C 
dbo.BID_RATES_PART_D

--- View Premium Amount
select PremC,PremD from tbPlanPBPSegPremSpans where PlanId='H1001' and PBPID='004' and segmentID='001' and EffectiveDate='2019-01-01 00:00:00.000'
--- Make Premium amount 0.00
update tbPlanPBPSegPremSpans
set PremC='0.00', PremD='0.00' where PlanId='H1001' and PBPID='004' and segmentID='001' and EffectiveDate='2019-01-01 00:00:00.000'
--- Update  Premium amount
update tbPlanPBPSegPremSpans
set PremC='40.60' where PlanId='H1001' and PBPID='004' and segmentID='001' and EffectiveDate = '2019-01-01 00:00:00.000'
--- Update  Premium amount 
update tbPlanPBPSegPremSpans
set PremD='31.10' where PlanId='H1001' and PBPID='004' and segmentID='001' and   EffectiveDate ='2019-01-01 00:00:00.000'

--------------------------------------------
--Letter Templates
--------------------------------------------

Select N.Letter_Type_ID, Letter_Name, Template_ID, T.IsActive from tbeam_Letter_Name N
Inner Join
tbEAM_Letter_Template T
On N.Letter_Type_ID = T.Letter_Type_ID

--------------------------------------------
--On Demand Letter Cleanup
--------------------------------------------
update TB_EAM_MEMBER_LETTERS set letter_type_iD = null where lettercode ='999'
update tbCorrespondence set letter_type_iD = null where lettercode ='999'
Truncate table tbEAM_Letter_Template
delete from tbEAM_Letter_Name

--------------------------------------------
-- MMP Plan Cleanup
--------------------------------------------
Select * from [dbo].[tbMMPMemberLoad]
Delete from [tbMMPMemberLoad] where PlanId = 'H0001' and PBPId = '004'

--------------------------------------------
-- Mapped Letter Templates with Plan, PBP, Year
--------------------------------------------
Select PlanID, PBPID, TemplateName, * from  [dbo].[ENRL_Letters_Templates_Map] TM
Inner Join
[ENRL_Letters_Templates] LT
On TM.LetterTemplateId = LT.LetterTemplateId
Where PlanID = 'H1001' and PBPID = '004' and EffYear = 2019

Select TransStatus,RxID,EffectiveDate,ReplyCodes,ReceiptDate,* from tbtransactions where HIC = '7C77C00PD09'
--Select TransStatus,RxID,EffectiveDate,ReplyCodes,ReceiptDate,* from tbtransactions where HIC = '7C77C00PD16'
Select SpanType,Value,StartDate,EndDate,* from tbENRLSpans where Hic = '7C77C00PD09'
--Select SpanType,Value,StartDate,EndDate,* from tbENRLSpans where Hic = '7C77C00PD14'

use EAM
select * from enrl_letters 
where 
lettercode In
(Select LetterCode from [dbo].[TB_EAM_MEMBER_LETTERS] 
Where 
MemCodNum IN (select MemCodNum from tbeenrlmembers  where hic in('7C77C00PD09')))

------------------------------------
TCS Letters QUEUE
-----------------------------------
http://asp-tms-tcs-2.dev.trizetto.com/TZ_Communication/batch/batchruns

----------------------------------------------
--TC TRC MAPPING
----------------------------------------------
Select * from ConfigurationManagerTcTrcActionMap
where transactioncode = 78

------------------------------------------
---SQL DB - Tables
------------------------------------------
SELECT TABLE_NAME, TABLE_SCHEMA FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE '%'

----------------------------------------------------------------------------------
-- SPAN Table
Select * from tbENRLSpans where Hic = '7C77C00AQ78'
----------------------------------------------------------------------------------
-- Update Multiple Plan/PBP allowed 1 - Allowed(It will create new Plan and PBP Member) 0 - Not Allowed 
Select Multiple, * from tbplan_pbp
Update tbplan_pbp set Multiple = 0

- When existing transaciton 61 is in pre cms state : user should not be able to created another 61 transaction in same plan
- When existing transaciton 61 is in pre cms state : user should be able to created another 61 transaction in different plan
- When existing transaciton 61 is in post cms state : user should be able to created another 61 transaction in different plan

When Multiple flag = 1 (On) so without member active user can create multiple plans and each plan create seperate member.
When Multiple Flag = 0 (Off) so with member active only user can create multiple plans and for that new transaction created not member
----------------------------------------------------------------------------------

-- Member ID ON/OFF Scenario

select * from tbplan_pbp  --PBPtype = 2 PDP, = 0 MA, = 1 MAPD
Select * from tbidtypes
Select * from tbPlans
----------------------------------------------------------------------------------
	  
	  
-- To see, EAF file Loaded error
Select Error,* from ElecAppFile where filename = 'EAF_BEQCreateMemberTC61_20181128.txt'

----------------------------------------------------------------------------------

-- To see, Enrolled member status
Select * from tbEENRLMembers where HIC = '7C77C00HD63'

----------------------------------------------------------------------------------

--To update, BEQ response file status
Update tbtransactions set transstatus=2  where HIC = 'HICN123456'

----------------------------------------------------------------------------------

-- INNER JOIN --
Select HCC_NAME,w.HCC_ID,RaftCode,HCC_Weight,w.Payment_Year,StartAge,EndAge
 from PTC_HCC_Weights w 
INNER JOIN tbRSM_PTC_HCC_DESC d 
on w.HCC_ID = d.HCC_ID 
Where w.Payment_Year = 2020 AND d.Payment_Year = 2020 And d.HCC_Name like '%ESRD%'
---------------------------------------------------------------------------------------

--Letter Part C and D PRemium

select * from [dbo].[fnENRL_Cal_Member_Premium_For_future_Eff_Date] (11654, 18098)

select TransID,MEmCodNum from tbtransactions where TransCode = 81 and HIC = '7C12C07PT12'

select * from [dbo].[fnENRL_Cal_Member_Premium_For_future_Eff_Date] (10370, 18104)

---------------------------------------------------------------------------------------

-- Look at Plan ID Types

Select * from tbidtypes

Select * From tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where idtype = 0 and pbptype = 0

---------------------------------------------------------------------------------------

-- Look at HIC and its RX details 

Select MemberID,RXID, RxGroup,RxBin,RxPCN,"2ndDrugInsur","2ndRXID", "2ndRXGroup",SecondaryBIN,SecondaryPCN from tbtransactions T
INNER JOIN tbEENRLMembers E 
On T.MemCodNum = E.MemCodNum where T.HIC = '7C77C00AA0008'
---------------------------------------------------------------------------------------

-- Cehck TRR loaded File status by HIC as Clim Number

Select ErrorDesc,Filename,* from [dbo].[TrrImportReportingWarehouse] where ClaimNumber = '7C77C01CD15'

---------------------------------------------------------------------------------------
-- Look at Plan Multiple Option and UPDATE

Select Multiple, PlanID from tbPlan_PBP
Update tbPlan_PBP set Multiple = 0 where PlanID = 'PDM04'
-----------------------------------------------------------------------------------------
-- MemCodNum having diffrent for same member
select HIC,memcodnum from  tbEENRLMembers where HIC in (
SELECT  HIC
FROM tbEENRLMembers
GROUP BY HIC
HAVING COUNT(*) > 1 )
-----------------------------------------------------------------------------------------

--Facets Member Search

select MEME_HICN, MEME_LAST_NAME, MEME_FIRST_NAME, MEME_SEX, MEME_BIRTH_DT, * from CMC_MEME_MEMBER

-- Facets MEmeber search through Member ID

Select * from [dbo].[CMC_SBSB_SUBSC] where SBSB_ID = 'MIDA109'

select MEME_HICN, MEME_LAST_NAME, MEME_FIRST_NAME, MEME_SEX, MEME_BIRTH_DT, * from CMC_MEME_MEMBER

select MEME_SSN, MEME_HICN, MEME_LAST_NAME, MEME_FIRST_NAME, MEME_SEX, MEME_BIRTH_DT, * from CMC_MEME_MEMBER where SBSB_CK > 1 and MEME_HICN <> ''


Select * from [dbo].[CMC_SBSB_SUBSC] where SBSB_ID = 'IHM160001' --'900061499'

select * from CMC_MEME_MEMBER where SBSB_CK =164750

select * from CMC_GRGR_GROUP where GRGR_CK = 178

-----------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------
EAF Fallout SSIS Package
-----------------------------------------------------------------------------------
'-- [ Step 1 - EAF Record's data dump into ElecAppFile ]
USE EAM
select Error,IsProcessed,* from elecappfile  where Error is not null And isprocessed <> 1 And FileName = 'EAF_Fallout_11111164.txt' 

'-- [ Step 2 - EAF Record's data copied into new designed tables ]
USE EAM 
Select * from [dbo].[EnrollmentManagerFalloutEafData] where FileName = 'EAF_Fallout_11111164.txt'
Select * from [dbo].[EnrollmentManagerFalloutEntities] where EntityId = 'AF273AC6-4355-428D-9E8B-EA2C8DAC4DE1'

'-- [ Step 3 - EAF Record's data copied into new designed tables; EAM Stagging to Warehouse ]
Use pdmupload
select * from [dbo].[tbImportEntities]
select * from [dbo].[tbFalloutEafData]

'-- [ Step 4 - EAF Record's data copied into new designed tables; EAM Warehouse tables ]
Use eamwarehouse
select * from [dbo].[HistoryInputManagerEntities] where EntityId = 'AF273AC6-4355-428D-9E8B-EA2C8DAC4DE1' 
select * from [dbo].[HistoryInputManagerFalloutEafData] where EntityId = 'AF273AC6-4355-428D-9E8B-EA2C8DAC4DE1'

'-- [ Step 5 - Utility picked record's from warehouse and perform validation; dump results in reasons table]
USE EAM
select * from [dbo].[EnrollmentManagerFalloutReasons] where EntityId = 'AF273AC6-4355-428D-9E8B-EA2C8DAC4DE1'

'-- [ Step 6 - Reason Id Mappped with Reason values ]
Select emfr.*,lkup.name,lkup.value from [EAM].[dbo].EnrollmentManagerFalloutReasons  as emfr 
Join [EAM].[dbo].eamlookup as lkup on emfr.reasonid = lkup.[key] and emfr.EntityId = 'AF273AC6-4355-428D-9E8B-EA2C8DAC4DE1'
order by entityid desc

-----------------------------------------------------------------------------------
EAF Fallout Error Lookup Master Table
-----------------------------------------------------------------------------------
'--Error Lookup Master Table
Select * from [EAM].[dbo].eamlookup

--------------------------------------------------------
 New Job Infrastructure
--------------------------------------------------------
USE PDMMetadata
select * from [dbo].[SchedulerJobGroups]
select * from [dbo].[SchedulerJobs] where jobgroupid='A74B58CF-EDCC-4695-8CD7-EAB5500F1BC4'
select * from [dbo].[SchedulerJobTriggers] where jobid='9D0EDD09-C490-43B7-A638-9F70F269F5DC' order by startdate desc
select * from [dbo].[SchedulerJobParameters] where triggerid='0AEA3402-F76C-49D5-8506-0FE9F7F82303'


-----------------------------------------------------------
EAF Falg ON/OFF
-----------------------------------------------------------
SELECT * FROM [PDMMetadata].[dbo].[ConfigurationManagerParameters] where [ParamaterId]='26EBB9D8-16FC-4FF4-AB38-32C4E700ED24'

'Value - True  - ON; False - OFF;

UPDATE [PDMMetadata].[dbo].[ConfigurationManagerParameters] 
SET [Value]=’false’
where [ParamaterId]='26EBB9D8-16FC-4FF4-AB38-32C4E700ED24'
'--------------------------------------------------------------

Variable Declartion 
---------------------------------------------------
declare @fileName varchar(100) = 'EAF_TransactionCodeTC6101_01012019.txt'
 
Select Error,IsProcessed, * from EAM.dbo.elecappfile where filename = @fileName

----------------------------------------


-------------------------------------------
Data Load Clean up
-------------------------------------------
select * from [dbo].[DataLoad_JobInfo] order by JobStartTime desc
select * from [dbo].[DataLoad_Status_Def]
select * from [dbo].[DataLoad_FileInfo]
--update [dbo].[DataLoad_FileInfo] set FileStatus = 4 where FileId = 20191118024609 
--update [dbo].[DataLoad_JobInfo]  set JobStatus = 4 where JobId = '395c77b3f4564cbe9e960cafe78d2a70' 

select * from [dbo].[DataLoad_JobInfo] order by JobStartTime desc
select * from [dbo].[DataLoad_Status_Def] 
select * from [dbo].[DataLoad_FileInfo]order by filestarttime desc   

-------------------------------------------
Data Load Reason of Failing Message - PDMUpload
-------------------------------------------
select * from DataLoad_Fallout_Data
select * from DataLoad_FileInfo order by filestarttime desc

'--------------------------------------
'Data Load File MApping
'--------------------------------------
Encounter - MAO
MMR : MONMEMD
MOR : HCCMOD
RxMOR : PTDMODD

MCMD : Medicaidstatus
RAPS - .RAPS
Spans - Spans
Provider - Provider

---------------------------------------------------------------
	Data Load File Upload Required/Optional Table Driven 
---------------------------------------------------------------
--Application ID/ Product ID
Use PDMMetadata
Select * from [dbo].[Applications]

--DLM Mandatory or Optional Files Info, 7 is for RAM
Use PDMMetadata
select * from tbDataloadProductFileTypeMap PFT 
Inner Join [tbDataloadFileTypes] FT
On PFT.FileID = FT.FileID
Where PFT.ProductID = 7

-- Table Driven File Mandatory or Optional
Use PDMMetadata
update tbDataloadProductFileTypeMap set ismandatory = 0 where ProductID = 7 and prodfilemapid >= 37 and prodfilemapid <= 41

-- File Info
Use PDMMetadata
select * from [dbo].[tbDataloadFileTypes] 

-----------------------------------------------------------------------------------

--BID Data Creator 

INSERT INTO TBLIPS 
SELECT RegionNum,State,SubsidyAmt,2021 FROM TBLIPS WHERE YEAR = 2020
INSERT INTO tbLISCoPays
SELECT 2021,Category,Description,CoPay,Deduct,StampDate FROM tbLISCoPays WHERE YEAR = 2020
INSERT INTO [BID_RATES_PART_C] ([CLIENT_ID],[PLANID],[PBP],[SEGMENT_ID],[SCC],[DEMO_AGED_PART_A],[DEMO_AGED_PART_B],[DEMO_DISABLED_PART_A],[DEMO_DISABLED_PART_B],[RISK_PART_A],[RISK_PART_B],[EFF_DATE],[EXP_DATE],[STAMP_DATE]) 
VALUES (98,'H1002','006','000','19250',0.00,0.00,0.00,0.00,528.15,477.24,'1/1/2021 12:00:00 AM',null,'06/02/2021 9:39:39 AM')
INSERT INTO [BID_RATES_PART_D] ([CLIENT_ID],[PLANID],[PBP],[DRUG_BID_TYPE],[BID_AMOUNT],[FED_REINSURANCE],[LISC],[PREMIUM],[BASIC_PREMIUM],[SUPPL_PREMIUM],[MEMBER_MONTHS],[LISC_MONTHS],[INDUCED_UTILIZATON],[NON_PHARMACY_EXPENSE],[GAIN_LOSS],[EFF_DATE],[EXP_DATE],[STAMP_DATE],[NON_SUPPL_PREMIUM], [SEGMENT_ID]) 
VALUES (98,'H1002','006','EA',105.85,40.73,165.45,0.00,52.43,0.00,0,0,0.000,0.00,0.00,'1/1/2021 12:00:00 AM',NULL,'6/02/19 9:39:39 AM',31.08, '000')
INSERT INTO [MEMBER_PREMIUM_PART_C] ([CLIENT_ID],[PLANID],[PBP],[BASIC_PREMIUM],[REBATE_AB_COST_SHARE],[REBATE_AB_SUPPL],[REBATE_PART_B_BUYDOWN],[REBATE_PART_D_BUYDOWN],[REBATE_PART_D_SUPPL_BUYDOWN],[EFF_DATE],[EXP_DATE],[STAMP_DATE],[SEGMENT_ID]) 
VALUES (98,'H1002','006',40.56,7.22,0.00,0.00,0.00,0.00,'1/1/2021 12:00:00 AM',NULL,'6/02/2021 9:39:39 AM','000')
insert into [tbPlanPBPSegPremSpans] 
values ('H1002', '006', null, '1/1/2021', '12/31/2021', '40.60', '31.10', 'pdmadmin', getdate())

-----------------------------------------------------------------------------------------

-- OSB Related Info 

Select * from [dbo].[tbEAM_OSBMemberInfo] Where MemCodNum in ( Select MemCodNum from tbtransactions where HIC = '7C77C00AQ71')
Select * from [dbo].[tbEAM_OSBTypes]
Select * from [dbo].[tbEAM_OSBConfig]
Select * from [dbo].[tbEAM_OSBTransactions]

-----------------------------------------------------------------------------------------

EAF Fallout Feature Enablment

SELECT * FROM [PDMMetadata].[dbo].[ConfigurationManagerParameters] where [ParamaterId]='26EBB9D8-16FC-4FF4-AB38-32C4E700ED24' 

------------------------------------------------------------------------------------------


Select HCCName,HCCNumber, HCCDescription from tbRAM_PTC_HCC_DESC where HCCName like 'ESRD%' and PaymentYear = 2019 And HCCNumber in (54,55,56,58,59,60,138) 


--PTC_HCC_HIERARCHIES

Select HCC_Keep, HCC_Drop, Payment_Year from [dbo].[Temp_HCC_HIERARCHIES$] where Payment_Year = 2019
Except
Select HCC_Keep, HCC_Drop, Payment_Year from PTC_HCC_HIERARCHIES where Payment_Year in (2020,2019)
Except
Select HCC_Keep, HCC_Drop, Payment_Year from [dbo].[Temp_HCC_HIERARCHIES$] where Payment_Year = 2020

--PTC_HCC_Weights

Select HCC_ID, RaftCode, HCC_Weight, Payment_Year, StartAge, EndAge from [dbo].[Temp_HCC_Weights$] where Payment_Year = 2020
Except
Select HCC_ID, RaftCode, HCC_Weight, Payment_Year, StartAge, EndAge from PTC_HCC_Weights where Payment_Year = 2020
Except
Select HCC_ID, RaftCode, HCC_Weight, Payment_Year, StartAge, EndAge from [dbo].[Temp_HCC_Weights$] where Payment_Year = 2020

--tbRSM_PTC_HCC_DESC

Select HCC_NAme,HCC_ID, HCC_Description from Test_tbRAM_PTC_HCC_DESC$
Except
Select HCCName,HCCNumber, HCCDescription from tbRAM_PTC_HCC_DESC where PaymentYear in (2019,2020) And HCCNumber in (54,55,56,58,59,60,138)
Except 
Select HCC_NAme,HCC_ID, HCC_Description from Test_tbRAM_PTC_HCC_DESC$

-- ESRD PTC_HCC_Weights

Select HCC_ID, RaftCode, Hcc_Weight, StartAge, EndAge from PTC_HCC_Weights where Payment_Year = 2019 and RaftCode in ('C1','C2','D','E1','E2','ED','I1','I2')
Except
Select HCC_ID, RaftCode, Hcc_Weight, StartAge, EndAge from [dbo].[Test_PTC_HCC_Weights$] Where RaftCode in ('C1','C2','D','E1','E2','ED','I1','I2')
Except
Select HCC_ID, RaftCode, Hcc_Weight, StartAge, EndAge from PTC_HCC_Weights where Payment_Year = 2019 and RaftCode in ('C1','C2','D','E1','E2','ED','I1','I2')

Select HCC_ID, RaftCode, Hcc_Weight, StartAge, EndAge from PTC_HCC_Weights Where Payment_Year = 2020 and RaftCode in ('C1','C2','D','E1','E2','ED','I1','I2')
Except
Select HCC_ID, RaftCode, Hcc_Weight, StartAge, EndAge from [dbo].[Test_PTC_HCC_Weights$] Where RaftCode in ('C1','C2','D','E1','E2','ED','I1','I2')
Except
Select HCC_ID, RaftCode, Hcc_Weight, StartAge, EndAge from PTC_HCC_Weights Where Payment_Year = 2020 and RaftCode in ('C1','C2','D','E1','E2','ED','I1','I2')

----RAM PTC_HCC_Hierarchies

 Select intHCCSequenceToDrop, intHCCSequenceToKeep, CriteriaID, LowestToKeep from PTC_HCC_Hierarchies where PaymentYear = 2020
 Except
 Select intHCCSequenceToDrop, intHCCSequenceToKeep, CriteriaID, LowestToKeep from [dbo].[Test_PTC_HCC_Hierarchies$]
 Except
 Select intHCCSequenceToDrop, intHCCSequenceToKeep, CriteriaID, LowestToKeep from PTC_HCC_Hierarchies where PaymentYear = 2020

 Select * from PTC_HCC_Hierarchies where PaymentYear = 2018  --2119 to 2262
 Select * from PTC_HCC_Hierarchies where PaymentYear = 2019  --2861 to 3015
 Select * from PTC_HCC_Hierarchies where PaymentYear = 2020  --3016 to 3170

----RAM PTC_HCCWeights

Select intHCCSequence, WeightTypeID, Weight from Test_PTC_HCCWeights$
Except
Select intHCCSequence, WeightTypeID, Weight from PTC_HCCWeights where PaymentYear in (2020,2019)
Except
Select intHCCSequence, WeightTypeID, Weight from Test_PTC_HCCWeights$

 Select * from PTC_HCCWeights where PaymentYear = 2018  -- 5558 to 5910
 Select * from PTC_HCCWeights where PaymentYear = 2019  -- 7881 to 8196
 Select * from PTC_HCCWeights where PaymentYear = 2020  -- 8197 to 8512

 Select Count(*) from PTC_HCCWeights where PaymentYear = 2019   -- 316
 Select Count(*) from PTC_HCCWeights where PaymentYear = 2020   -- 316

Select * from PTC_HCCWeights where paymentYear  = 2019 and WeightTypeID = 3


Select * from PTC_HCCs


Select HCCName,HCCNumber, HCCDescription from tbRAM_PTC_HCC_DESC where PaymentYear = 2017 And HCCNumber in (54,55,56,58,59,60,138)


Select * from PTC_HCCs where intHCCSequence in (304,305,306,307)


--RSM Merge - PTC_HCC_HIERARCHIES

Select * from  Merge_PTC_HCC_HIERARCHIES$
Except
Select * from PTC_HCC_HIERARCHIES 
Except
Select * from  Merge_PTC_HCC_HIERARCHIES$

--RSM Merge - PTC_HCC_Weights

Select * from  Merge_PTC_HCC_Weights$ where Payment_Year in (2019,2020)
Except
Select * from PTC_HCC_Weights where Payment_Year in (2019,2020)
Except
Select * from  Merge_PTC_HCC_Weights$ where Payment_Year in (2019,2020)

--RSM Merge - tbRSM_PTC_HCC_DESC 

Select * from  Merge_tbRSM_PTC_HCC_DESC$
Except
Select * from tbRSM_PTC_HCC_DESC where Payment_Year in (2019,2020)
Except
Select * from  Merge_tbRSM_PTC_HCC_DESC$

--RSM Merge - tbRSM_PTC_HCC_DESC 

Select * from  Merge_PTC_HCC$
Except
Select * from PTC_HCC
Except
Select * from  Merge_PTC_HCC$

