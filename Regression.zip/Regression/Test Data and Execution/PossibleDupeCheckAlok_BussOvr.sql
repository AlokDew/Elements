
Update tbplan_pbp set multiple = 0

Select * from tbtransactions where hic = '7A77AA0DA01'
 
Select * from tbtransactions where hic = '7C77SD0SD01'


 
Select Error,IsProcessed,DupeEditOvr,ApplicantHICN from elecappfile where filename = 'EAF_MultipleOffX02_20200101.txt'

Select Error,IsProcessed,DupeEditOvr,ContractID, PlanID,ApplicantHICN 
from elecappfile where filename = 'EAF_MultipleONY03_20200101.txt'
And IsProcessed = 1

Select M.SpouseWorkStatus,M.AccessibilityFormat,M.EmailOptIn,T.HIC from tbMemberInfo M
Join tbtransactions T On M.Memcodnum = T.Memcodnum 
Where T.HIC = '7C77SD0SD10'

Select S.SpanType,T.DateEditOvr,T.TransStatus,* from tbtransactions T Inner Join tbENRLSpans S
On T.Hic =  S.Hic
where T.Hic =  '7C77SD0SD17' 

