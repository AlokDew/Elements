--******************************************************
--		ICEP
--******************************************************
--'7B77C00AZ20,7B77C00AZ21'
Exec BEQResponse_Generator '1D77C00AA01,1D77C00AA02',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					
					
--Remove 88,89,91,92 Blank	Position 717
--------------------------------------				
--'7B77C00AZ23'					
Exec BEQResponse_Generator '1D77C00AA03',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200101;
MedPartBEntStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					
					
--Remove 88,89,91,92 Blank	Position 717
--------------------------------------
--'7B77C00AZ24'
exec BEQResponse_Generator '1D77C00AA04',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'				
					
--Remove 88,89,91,92 Blank Position 717
					
--******************************************************
--		IEP
--******************************************************
--'7B77C00AZ25,7B77C00AZ26'
Exec BEQResponse_Generator '1D77C00AA05,1D77C00AA06',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
PartDEligibilityStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'
					
--Remove 88,89,91,92 Blank Position 717
---------------------------------------
--'7B77C00AZ51'
Exec BEQResponse_Generator '1D77C00AA07',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'		

--No further update required 	
-----------------------------------------
--'7B77C00AZ53'
Exec BEQResponse_Generator '1D77C00AA08',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
PartDEligibilityStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

--Remove 88,89,91,92 Blank	 Position 717	
					
--******************************************************
--		IEP2
--******************************************************
--'7B77C00AZ57,7B77C00AZ58'					
Exec BEQResponse_Generator '1D77C00AA09,1D77C00AA10',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
PartDEligibilityStartDate=20190101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

--No further update required 
--------------------------------------------------					
--'7B77C00AZ63,7B77C00AZ64'	
Exec BEQResponse_Generator '1D77C00AA11,1D77C00AA12',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20200201;
MedPartBEntStartDate=20200201;
PartDEligibilityStartDate=20200201;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'				
					
--No further update required 	
					
--******************************************************
--		Flow 2
--******************************************************	
--'7B77C00AZ27,7B77C00AZ28,7B77C00AZ29,7B77C00AZ30,7B77C00AZ31'

Exec BEQResponse_Generator '1D77C00AA13,1D77C00AA14,1D77C00AA15,1D77C00AA16,1D77C00AA17',   
'ProcessedFlag=Y;   
BeneficiaryMatchFlag=Y;   
MedPartAEntStartDate=20110101;   
MedPartBEntStartDate=20110101;
PartDEligibilityStartDate=20110201;
NotLawfulPresenceEndDate10=20110101;   
CurrentEnrlSrcTypeCodePartCD=A;   
CurrentEnrlSrcTypeCodePartC=D;'
					
--No further update required

--******************************************************
--		Flow 4
--******************************************************
--'7F77C00AY10,7F77C00AY12'

Exec BEQResponse_Generator '1D77C00AA18,1D77C00AA20',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190101;
MedPartBEntStartDate=20190101;
MedPartBEntEndDate=20200101;
PartDEligibilityStartDate=20190101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'

--No further update required
-----------------------------------------
--'7F77C00AY11'
Exec BEQResponse_Generator '1D77C00AA19',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190101;
MedPartBEntStartDate=20190101;
MedPartBEntEndDate=20200731;
PartDEligibilityStartDate=20190101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

--No further update required
---------------------------------------
--'7F77C00AY13,7F77C00AY14'

Exec BEQResponse_Generator '1D77C00AA21,1D77C00AA22',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190101;
MedPartBEntStartDate=20190101;
PartDEligibilityStartDate=20190101;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'	

--No further update required 				


--******************************************************
--		Q11 -- PACE
--******************************************************				
--'7B77C00AZ92,77B77C00AZ94,7B77C00AZ95'
				
Exec BEQResponse_Generator '1D77C00AA23,1D77C00AA25,1D77C00AA26',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190101;
MedPartBEntStartDate=20190101;
PartCDPlanType=20;
PartCPlanType=20;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					

--7B77C00AZ92 - Remove 749-750
--7B77C00AZ94 - Remove 749-750;755-756
--7B77C00AZ95 - Remove 749-750
---------------------------------------
--'7B77C00AZ93'
Exec BEQResponse_Generator '1D77C00AA24',
'ProcessedFlag=Y;
BeneficiaryMatchFlag=Y;
MedPartAEntStartDate=20190101;
MedPartBEntStartDate=20190101;
PartDEligibilityStartDate=20190101;
PartCDPlanType=20;
CurrentEnrlSrcTypeCodePartCD=A;
CurrentEnrlSrcTypeCodePartC=D;'					
	
--No further update required				
					
					
					
					
					
					
					
					
					
					
				
					
					
					
					
					
					
				
					
					
					
				
					
					
					
					
					
					
					

					
					
					
					

					
					
					
					
					
					

					
					
					
					
					
					
					
					
				
					
					
					
					
					
					
					
					
					
					
