-- SOILBZ

Select * from tbtransactions where HIC like '7A77AA0TR%'

Select HIC,PlanID,PBPID  from tbtransactions where HIC like '7A77AA0TR%' group by HIC,PlanID,PBPID Having Count(TransCode) = 1

Select PlanID,PbpID,* from tbtransactions where hic like '7A77AA0AD%'

Select HIC,PlanID,PBPID  from tbtransactions where HIC like '7A77AA0AD%' group by hic,PlanID,PBPID Having Count(TransCode) = 1

--- 19686--------------

Select PLANID,PBP,EFF_DATE,*  from BID_RATES_PART_D Where PlanID in ('H1002','PDM01') AND PBP in ('006','001') AND EFF_DATE in ('2019','2020','2021')

Select * From tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where pbptype = 1
And tbpbp.PlanId  in ('H1002','PDM01')

Select * from [dbo].[tbEAM_OSBConfig]
Select * from [dbo].[tbEAM_OSBTypes]
--Delete [dbo].[tbEAM_OSBConfig] WHere PLANID = 'H1002'
--Update tbEAM_OSBConfig Set UserModified = 'tmsadmin' where OSBID = 1
--Select * from [dbo].[tbEAM_OSBConfig] WHere PLANID = 'PDM01'
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','009',10,5,'2019-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','009',11,5,'2019-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','009',1015,5,'2019-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','009',17,5,'2019-01-01','2021-12-31','tmsadmin','2020-04-01')

Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',1,40,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',2,50,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',3,10,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',4,70,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')

Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',1,50,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',2,6,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',3,12,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('H1002','006',4,75,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')


Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',1,5,'2019-01-01','2019-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',2,1,'2019-01-01','2019-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',3,2.5,'2019-01-01','2019-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',4,20,'2019-01-01','2019-12-31','tmsadmin','2020-04-01')

Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',1,10,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',2,2,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',3,5,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',4,35,'2020-01-01','2020-12-31','tmsadmin','2020-04-01')

Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',1,30,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',2,3,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',3,7.5,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')
Insert into [dbo].[tbEAM_OSBConfig] values ('PDM01','001',4,75,'2021-01-01','2021-12-31','tmsadmin','2020-04-01')

---- 34192 | Tushar OnDemand Letter
SELECT *  FROM [EAM].[dbo].[ENRL_Letters_Templates_Map] where lettercode ='999' AND  PlanID = 'H1001' order by EffYear desc


----- IDTYPE Member/Trasnaction
Select * from tbtransactions where hic like '7C77CA0AD%'

Select * from tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where idtype = 3 and pbptype = 2

Update tbtransactions Set TransStatus = 4 Where hic = '7C77CA0AD12'

---- Plan/CMs Initiative Rahul P-----------------------
Select  PremPart, * from [EAM].[dbo].[tbtransactions] where transId = '23864'

Select PWOption, * from [EAM].[dbo].[tbmemberinfo] where MemCodNum = '13412'

Select  * from [EAM].[dbo].[MemberManagerScheduleFutureUpdate] where FutureUpdateType = 3 and TransId = '23864'

Update [EAM].[dbo].[MemberManagerScheduleFutureUpdate] set EffectiveDate = '2020-04-01 00:00:00'
where TransId = '23864'

------ 27096--------
Select PWOption, * from [EAM].[dbo].[tbmemberinfo] where MemCodNum in (Select MemCodNum from tbtransactions where hic like 'MBIOECLAY%')
Select PremPart,hic,* from tbtransactions where hic like 'MBIOECLAY%'

---------- Enrollment Services ------------------------

--Basic_Auth
--Client ID - tms_gateway
--TriZettoElementsGatewaySecret

Select ApplicationDate, ReceiptDate, EffectiveDate, * from tbTransactions where hic = '7B77C00DD01'
Select * from tbEENRLMembers where memcodnum = '10966'
Select * from tbMemberInfo WHERE memcodnum = '10966' 

--Verify that Warehouse table updated with enitydata,RequestType&Request Status and if any erro,then with Error ID
--Request save in below table:-
select * FROM [EAMWarehouse].[dbo].HistoryInputManagerEntities Where RequestId = 'e5438e4d-3c73-4e9e-9ee7-3e96179dfefa'
--Request status and type:-
select * FROM [EAMWarehouse].[dbo].HistoryInputManagerRequests Where RequestId = 'e5438e4d-3c73-4e9e-9ee7-3e96179dfefa'
--If any Error, Error ID will get from below table:-
--select * FROM [EAMWarehouse].[dbo].HistoryInputManagerErrors
--Error discerption:-
select * from [EAMWarehouse].[dbo].WarehouseLookup w where w.[Key] in (select errorid FROM [EAMWarehouse].[dbo].HistoryInputManagerErrors where EntityID='F697979D-9DD9-4E97-9937-2C44D11CF5AF')

Select SalesRepID,* from tbtransactions where hic = '7F77C00DD01'

Select SalesRepID,* from tbMemberInfo WHERE memcodnum = '11047' 

------------------------------------------------------------

Select * From tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where pbptype = 2


Select * from tbPlan_pbp tbpbp inner join tbPlans tbplan
on tbpbp.PlanId = tbPlan.PlanId
Where idtype = 3 and pbptype = 1

Update tbtransactions Set TransStatus = 2 Where hic = '7A77AA0AD23'

 Select * From TB_EAM_PLAN_TO_SCC_MAPPING tbPnScc inner join TB_EAM_ZIP_TO_SCC tbzscc on tbPnScc.scc = tbzscc.SCC

 Select error,* from elecappfile where filename  = 'EAF_BEQCreateMemberTC61_20181111.txt'


 Select value,* from EAM.[dbo].[tbENRLSpans] where HIC = '7C77C00QA70'

Select * from [dbo].[tbLanguage]

Select language,Applicanthicn,* from elecappfile where isprocessed = 1 and Language <> 'ENG'

------------------------
--35270
update tbPCP
set AcceptAssignment = '0' where ProvID = '1000048'

update tbPCP
set AcceptAssignment = '0', AcceptNewMem = '0' where ProvID = '100008'

update tbPCP
set AcceptAssignment = '0', AcceptNewMem = '0', ParticipateMA = '0' where ProvID = '100010'

update tbPCP
set AcceptAssignment = '0', AcceptNewMem = '0', ParticipateMA = '0', AllowAsPCP = '0' where ProvID = '1000195'

select COUNT(1) as Total_records_1 from tbPCP where AcceptAssignment = '1' 
 
select COUNT(1) as Total_records_2 from tbPCP where AcceptAssignment = '0'
 
select COUNT(1) as Total_records_3 from tbPCP