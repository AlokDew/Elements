

Select * from tbtransactions where hic like '7A77A01AP%'

Select b.segmented,PBPtype,* From tbPlan_pbp b inner join tbPlans p
on b.PlanId = p.PlanId
Where p.PlanID in ('H0002','H0003','PDM04','H1004','S2003','S2004')
And PBPID IN ('001','006','014','019','011','016')

Select Error,IsProcessed,language,* from ElecAppFile Where Filename = 'EAF_TC61F92Y001_01012020.txt'

Select T.HIC,T.TransCode,T.TransStatus,T.PlanID,T.PBPID,T.Language as 'T Lang',T.AccessibilityFormat as 'T Accessbility',
EE.MemberStatus,M.Language as 'M Lang',M.AccessibilityFormat as 'M Accessibility' from tbmemberinfo M join tbtransactions T
On M.MemcodNum = T.MemCodNum Join tbEENRLMembers EE
On EE.HIC = T.HIC Join ElecAppFile E
On E.Applicanthicn = T.HIC
Where E.Filename = 'EAF_TC61F92Y001_01012020.txt'

/*
Select T.HIC,T.MemberStatus,T.PlanID,T.PBP,M.Language,M.AccessibilityFormat from tbmemberinfo M join tbEENRLMembers T
On M.MemcodNum = T.MemCodNum Join ElecAppFile E
On E.Applicanthicn = T.HIC
Where E.Filename = 'EAF_LangAccessTC61Y001_01012020.txt'
*/

Update tbtransactions Set TransStatus = 4 Where HIC
In ('7A77A01RP02','7A77A01RP05','7A77A01RP06')

Select HIC,TransID from tbtransactions Where HIC
In ('7A77A01RP02','7A77A01RP05','7A77A01RP06')

Select Error,IsProcessed,Applicanthicn,* from ElecAppFile Where Filename = 'EAF_TC92Buss01Y01_01012020.txt'

Select Error,IsProcessed,Applicanthicn,* from ElecAppFile Where Filename = 'EAF_TC92Buss02Y01_01012020.txt'

Select Error,IsProcessed,Applicanthicn,* from ElecAppFile Where Filename = 'EAF_TC92Buss02Y02_01012020.txt'


Select T.HIC,T.MemberStatus,T.PlanID,T.PBP,M.Language,M.AccessibilityFormat from tbmemberinfo M join tbEENRLMembers T
On M.MemcodNum = T.MemCodNum Join ElecAppFile E
On E.Applicanthicn = T.HIC
Where E.Filename = 'EAF_TC92Buss02Y01_01012020.txt'

Select TransId,MemCodNum from tbtransactions Where TransCode = '92' And HIC = '7A77A01AP01'

 


Select Error,IsProcessed,Applicanthicn,* from ElecAppFile Where Filename = 'EAF_TC6192Y002_01012020.txt'

	
Select * from [EAMWarehouse].[Audit].[TransactionLevel_Audit] 
Where TransID = '29445' And MemCodNum = '21413'

Select T.HIC,T.Transcode,AE.FieldName,OriginalValue,NewValue,TriggerActionType From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Join tbtransactions T
On A.Transid = T.TransID And A.MemCodNum = T.MemCodNum Join PDMMetadata.dbo.[AuditEntityFields] AE 
On AE.FieldId = A.FieldId
Where AE.FieldName In ('Language','AccessibilityFormat','SnpStatusType','OnHoldReasonId')
And T.TransCode = '92'
And T.HIC = '7A77A01AP02'
Order By AuditDate

Select Transid from tbtransactions where hic = '7A77A01APX1' and TransCode = '92'

Update tbtransactions Set TransStatus = 4 Where Transid = '29445'


Select T.HIC,T.Transcode,AE.FieldName,OriginalValue,NewValue,TriggerActionType From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Join tbtransactions T
On A.Transid = T.TransID And A.MemCodNum = T.MemCodNum Join PDMMetadata.dbo.[AuditEntityFields] AE 
On AE.FieldId = A.FieldId
Where AE.FieldName In ('Language','AccessibilityFormat','SnpStatusType','OnHoldReasonId')
And T.TransCode = '92'
And TriggerActionType = 'Add'
And T.HIC In ('7A77A01APX1','7A77A01AP02','7A77A01AP03','7A77A01APX4','7A77A01AP05','7A77A01AP06')
Order By AuditDate

Select T.HIC,T.Transcode,AE.FieldName,OriginalValue,NewValue,TriggerActionType From [EAMWarehouse].[Audit].[TransactionLevel_Audit] A Join tbtransactions T
On A.Transid = T.TransID And A.MemCodNum = T.MemCodNum Join PDMMetadata.dbo.[AuditEntityFields] AE 
On AE.FieldId = A.FieldId
Where AE.FieldName In ('Language','AccessibilityFormat','SnpStatusType','OnHoldReasonId')
And T.TransCode = '92'
And TriggerActionType = 'Change'
And T.HIC In ('7A77A01APX1','7A77A01AP02','7A77A01AP03','7A77A01APX4','7A77A01AP05','7A77A01AP06')
Order By AuditDate




Select * from tblanguage
Select multiple from tbplan_pbp
Update tbplan_pbp set multiple = 0 

Select * from tbEENRLMembers where hic like '7A77A01AP0%'
Select * from [dbo].[tbMemberStatus]

Select * from [dbo].[tbCustConnectMapping]

SELECT TOP 100 [custConnectMappingId],[PlanId],[GUID],[RACFID],[LastModified],[EIDM]FROM [EAM].[dbo].[tbCustConnectMapping] 

Delete from [tbMMPMemberLoad] where PlanId = 'H1001' and PBPId = '004'