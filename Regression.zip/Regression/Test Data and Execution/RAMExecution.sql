
exec PIR_GetProviderAndPIR '88','','',0

exec PIR_GetProviderWithGroup '88','',''
exec PIR_GetProviderWithGroupAffiliation '88','',''

------------------------------------------------------------------------------------------------------
		---	 PREPARE DATA FOR GROUP AND AFFILIATION RAM - MANAGE SUSPECT SEARCH
------------------------------------------------------------------------------------------------------

--Step 1: Select Six (Group,Affliation) intClaimID  - 4457742,4457062,4455280,4455161,4454288,4452466
Select distinct Top 6 E.intClaimID,E.txtProviderID,E.stampdate,E.stampuser from tbDiags D Inner join tbExceptionLetters E
ON D.intClaimID = E.intClaimID Inner Join [tbProvider] P
On E.txtProviderID = P.txtProviderID 
Where D.intClaimID is Not Null 
Order by E.intClaimID Desc

--Step 2: Verify [tbProviderGroup] has records, If not then Insert records Step 3
Select * from [dbo].[tbProviderGroup]
--Delete [tbProviderGroup] where txtGroup = 'ABCD'

--Step 3: Updtae GroupID in Provider Table based upon Provider ID fetched in Step 1
Update [tbProvider] Set txtGRoupID = 'GRP001', IntStatus = 0 Where txtProviderID = '040426006761'
Update [tbProvider] Set txtGRoupID = 'GRP002', IntStatus = 0 Where txtProviderID = '040426006671'
Update [tbProvider] Set txtGRoupID = 'GRP003', IntStatus = 0 Where txtProviderID = '040426007694'
Update [tbProvider] Set txtGRoupID = 'AGRP001', IntStatus = 1 Where txtProviderID = '050818000005'
Update [tbProvider] Set txtGRoupID = 'AGRP002', IntStatus = 1 Where txtProviderID = '040426014251'
Update [tbProvider] Set txtGRoupID = 'AGRP003', IntStatus = 1 Where txtProviderID = '070820000013'

--Step 4: Make sure updated in Provider Table
Select * from [tbProvider] where txtGroupID <> '' 

--Step 5: Inser Records in to [tbProviderGroup] table by updting stamp date and user from Step 1

Insert into [tbProviderGroup] values ('88','GRP001','MangSusGrp1','ADD1','ADD2','MIAMI','FL','33134','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','GRP002','MangSusGrp2','ADD1','ADD2','MIAMI','FL','33134','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','GRP003','MangSusGrp3','ADD1','ADD2','MIAMI','FL','33134','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','AGRP001','MangSusAffGrp1','ADD1','ADD2','NewYork','NY','10121','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','AGRP002','MangSusAffGrp2','ADD1','ADD2','NewYork','NY','10121','','','','','2016-05-25 17:21:00','admin') 
Insert into [tbProviderGroup] values ('88','AGRP003','MangSusAffGrp3','ADD1','ADD2','NewYork','NY','10121','','','','','2016-05-25 17:21:00','admin') 

--Step 6: Update tbdiags for Group from based on records fetched from 1,2,3 in Step 1

Update tbDiags Set intSuspectStatus = '10' Where intClaimID = '4457742'
Update tbDiags Set intSuspectStatus = '10' Where intClaimID = '4457062'
Update tbDiags Set intSuspectStatus = '10' Where intClaimID = '4455280'


------------------------------------------------------------------------------------------------------
		---	 REMOVE DATA FOR GROUP AND AFFILIATION RAM - MANAGE SUSPECT SEARCH
------------------------------------------------------------------------------------------------------

Delete from [tbProviderGroup]

------------------------------------------------------------------------------------------------------
		---	 RAM Process FLow
------------------------------------------------------------------------------------------------------
--1. Login to RAM
--2. Enter New Diagnosis Data
--3. Enter Member ID
--4. Enter all data for new Dia including Chart ID
--5. Make it On Hold or Without Hold -- If On Hold then go and release it from Task -> On-Hold and Diagnosis Review
--6. Reports -> CMS queue Report  - Payment Year (Diag Add year + 1), Start and End Date Within Diag Add Date
--7. Tasks -> Export -> CMS Export -> Same Member's Plan ID
--8. Continue from Step 5 if On Hold
--9. Admin -> Flag from Auditor Review
--10. Upload Auditor file with Char Id 000 as mentioned during Diag Entries
--11. Admin -> Auditor Review -> File Or Parameter
--12. Mark Review Complete

--Note: RAM CMS Extract File Can be Imported as CDM RAPS Extract

------------------------------------------------------------------------------------------------------
		---	 MisCellenous
------------------------------------------------------------------------------------------------------
--RAM Member
Select txtMemberId,* from [RAM].[dbo].[tbmember] where txtmemberid = '01234567890'

--Note: Take Diagnosis Code from this query
select * from [RAM].[dbo].[icd9codes] where icdversion =1        
--Column --> CodeValue       
 
--Note 2: Choose the Encounter Dates on the basis of output of this query
select * from [RAM].[dbo].[tbMemberPlan] where txtmemberid = '01234567890'

--Encounter Year Date Range
Select PayMon
from tbSpanLoadMonthly
Where PayMon <= GetDate() and bntMemberid = '' 
 
--Note 3: Take Provider ID from this query
select * from [RAM].[dbo].[tbProvider] where txtProviderID = '1821221144'

-- Auditor Review Complete -- Claim On Hold Status
Select * from tbClaimOnHold Where txtMemberId = 'MEM00126144'

--- PIR( IntStatus) Number in Open State ---
select intControlNum,* from tbexceptionletters where intstatus =-1

--Reason Code Table
select * from tbReasons where Description = 'TestOEDReason'



Select * from tbexceptionletters
Select * from tbDiags
Select * from tbProvider
Select * from tbMember

--[OnHoldReasons] Master table 
SELECT *   FROM [RAM].[dbo].[OnHoldReasons]

-- On Hold Release Table 
select * from tbClaimOnHold  where isDeleted = 0 and AuditStatus = '1'

--- RXHCC Data Retrive 
Select * from tbmember 

Select * from tbMember_RxHCC where bntmemberID In ( Select bntMemberID from tbmember) order by Stampdate desc

---- Claim ID Populates
select top(1) txtPlanClaimID from tbdiags d
inner join tbClaim c
on d.intClaimID = c.intClaimId
inner join tbMemberPlan m
on d.bntMemberID = m.bntMemberID
where intDiagSource=1 and dteCMSFile is Null and d.Isdeleted =0 and d.intKnownStatus = 1 order by d.stampdate desc 


--Get the PIR control number which is not submitted yet by using query :
SELECT [intControlNum],[intStatus],[bntMemberId],* 
FROM [RAM].[dbo].[tbExceptionLetters] where intstatus=-1


  --------------------------------------------------------------
  ---Manage Suspect Search
  --------------------------------------------------------------
  Declare @ClientId varchar(15) = null  
Declare @LastName varchar(50) = null   
Declare @PlanMemberId varchar(25) = null   

Select     
 *
From    
 tbExceptionLetters el    
Inner Join    
 tbDiags d    
On    
 --el.intClaimId = d.intClaimId    
 --and el.intDiagNum = d.intDiagNum    
  
 --MEDICAL:    
  
 (el.intClaimId = d.intClaimId    
 and el.intDiagNum = d.intDiagNum    
 and d.intDiagsource in (1,6,7,9)    
 and el.bntMemberId = d.bntMemberId)    
 or    
--Client Identified  
 (el.tbDiagsId = d.tbDiagsId    
 and d.intDiagsource = 3   
 and el.bntMemberId = d.bntMemberId  
)  
or  
--Improve
 (el.tbDiagsId = d.tbDiagsId    
 and d.intDiagsource = 10   
 and el.bntMemberId = d.bntMemberId  
)   
  
Inner Join     
 tbMember m    
On     
 el.bntMemberId = m.bntMemberId    
Where    
 el.txtClientId = @ClientId    
 and el.intStatus in (-1,0)    
 and d.intSuspectStatus not in (10)  
 and (@LastName is Null or @LastName is not null and m.txtLast like @LastName + '%')    
 and (@PlanMemberId is Null or @PlanMemberId is not null and m.txtMemberId = @PlanMemberId)    
Order By    
 el.intControlNum, txtICD9Code  
 --------------------------------------------------------------

 Select * from tbexceptionletters el
Inner Join     
 tbMember m    
On     
 el.bntMemberId = m.bntMemberId

 Select * from tbexceptionletters el
Inner Join     
 tbMember m    
On     
 el.bntMemberId = m.bntMemberId  

 Select bntMemberId,* from tbMember

 Update tbexceptionletters Set intStatus = 0, bntMemberid = 36 Where intControlNum = 4

  Update tbMember Set bntMemberId = 4 Where txtMemberId = '01234567890'

--Note --7 - I guess cancel
--1 - closed
--InStatus = PIR Status = Suspect Status
 --------------------------------------------------------------




--Step1 :Fetching value of member id(txtmememberid) and HICNumber  .Select a memberid and hic from table. Note down txtMemberID and hic number from this table
 
       select memberplanid , HicNumber,txtMemberID, * from ram.dbo.tbmemberplan where txtMemberID = 'MEM00250186'
 
--Step2 : Fetching value of HCC . HCC value should be numberic and do not have any characters for HCC17 value should be 17 .Note down any hcc value from this table
 
        select  distinct HCCnumber ,* from ram.dbo.tbRAM_PTC_HCC_DESC where HCCNumber	= 17
 
--Step3: Fetching Enter a payment year which is within members eligibility .Select payment year based on Members eligibility 
 
       select dtebegin , dteend, * from ram.dbo.tbmemberplan
 
--Step4:  Fetching value for provider ID, Provider first name and last name  .Select provider id , provider first name and Provider last name from below table .note down provider id and first name , last name 
 
        select txtProviderID,txtFirst,txtlast, * from ram.dbo.tbProvider


		SELECT *   FROM [PDMUpload].[dbo].[SUSPECTSTImportTemp]

		SELECT intControlnum, * FROM   ram.dbo.tbExceptionLetters WHERE tbDiagsID is not null and suspid =999
		And txtProviderID = '040426029149'

----- To Check On Hold Record which are on Hold and Diagnose Review

	select isblocked,pirstatus ,intcontrolnum,isdeleted from tbClaimOnHold tc
	inner join onholdreasons oh
	on tc.onHoldReasonId=oh.id where intcontrolnum=1362


	select CodeValue, * from [RAM].[dbo].[icd9codes] where icdversion =1  

	select * from [RAM].[dbo].[tbMemberPlan] where txtmemberid = 

	select * from tbClaimOnHold where txtMemberID = 'MEM00156476'

